<?php require_once("config/connection.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>E-Job Portal</title>
    <link rel="stylesheet" href="css/bootstrap.css" >
    <link rel="stylesheet" href="css/font-awesome.min.css" >
    <link rel="stylesheet" href="css/style.css" >	
    <link rel="stylesheet" href="css/home.css" >	
    <script type="text/javascript" src="js/jquery.js"></script>  
    <script type="text/javascript" src="js/bootstrap.min.js"></script>	
	 <script type="text/javascript" src="js/jquery.pwdMeter.js"></script>
	 <style>
			.navbar{
				background-color: #1ABC9C ;
			}
			
		</style>
</head>

<body>
<div class="container">
        <br><br><br>
	    <div class="row">            
              <img class="img-responsive"  src="images/01.jpg" alt="">           
        </div>
        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" style="color: white" >E-Job </a>
                </div>
				
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a style="color: white" href='index'><i class="fa fa-home fa-fw"></i>&nbsp;Home</a></li>                                           	
						<li class="dropdown">
                            <a href="#" style="color: white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                &nbsp; Career Services
                             <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href=""><i class="fa fa-pencil fa-fw" ></i>&nbsp;Resume</a></li>                                
                                <li><a href=""><i class="fa fa-pencil fa-fw" ></i>&nbsp;Cover Letter</a></li>                                
                                <li><a href=""><i class="fa fa-pencil fa-fw" ></i>&nbsp;Interview Tips</a></li>                               			
                                <li><a href=""><i class="fa fa-pencil fa-fw" ></i>&nbsp;Interview Preparing</a></li>                               			
                                <li><a href=""><i class="fa fa-pencil fa-fw" ></i>&nbsp;Interview Question</a></li>                               			
                            </ul>
                        </li>																	                        						
                        <li><a style="color: white" href="#"> Job Seeker</a></li>
                        <li><a style="color: white" href="#"> Employers</a></li>
                        <li><a style="color: white" href="Contact"> Contact</a></li>
                    </ul>

					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown"><a style="color: white" class="dropdown-toggle" data-toggle="dropdown" href="#">
										<i class="fa fa-user"></i> Register <span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="JobSeeker/Register">Jobseeker</a></li>
								<li role="separator" class="divider"></li>
								<li><a href="Employers/Register">Employer</a></li>
							</ul>
						</li>
						<li><a style="color: white" href="login"><i class="fa fa-sign-in"></i> Login</a></li>
					</ul>
                </div>           
            </div>       
	   </nav>    
</div>
