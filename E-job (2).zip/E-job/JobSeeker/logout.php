<?php

session_start();
// Check, if user is already login, then jump to RESULT page
if (!isset($_SESSION['username']) || !isset($_SESSION['password'])) {
 header('Location: index');
}
?>
<?php


session_start();
unset($_SESSION['username']);
session_destroy();
header('Location: ../index');

?>
