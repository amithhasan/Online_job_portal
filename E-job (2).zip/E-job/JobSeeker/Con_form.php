<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
 <?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "project"; //Database name

	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}

	$name = $_POST["name"];
	$email  = $_POST["email"];
	$mobile  = $_POST["mobile"];
	$subject  = $_POST["subject"];
	$comment  = $_POST["comment"];
	
	


	$sql = "INSERT INTO `contact`(`name`, `email`, `mobile`, `subject`, `comment`, `id`) VALUES ('$name','$email','$mobile','$subject','$comment', '')";
	

	if (mysqli_query($conn, $sql)) {
		echo "<script>alert('Thank you for your comment!'); window.location='index.php'</script>";;
	} 
	else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?> 