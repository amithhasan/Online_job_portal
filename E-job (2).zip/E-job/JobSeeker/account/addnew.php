<?php require_once('../session.php'); ?>
<?php require_once('../functions.php'); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('Location: ../../Login');
	
	
	}	
?>
<?php
	error_reporting( ~E_NOTICE ); // avoid notice	
	require_once 'dbconfig.php';	
	if(isset($_POST['btnsave']))
	{
		$userid=$_SESSION['user_id'];
		
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) 
		{
			$ip_address = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) 
		{
			$ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else 
		{
			$ip_address = $_SERVER['REMOTE_ADDR'];
		}
		
		
		$imgFile = $_FILES['user_image']['name'];
		$tmp_dir = $_FILES['user_image']['tmp_name'];
		$imgSize = $_FILES['user_image']['size'];
		
		
		
		if(empty($imgFile)){
			$errMSG = "Please Select Image File.";
		}
		else
		{
			$upload_dir = 'user_images/'; 
	
			$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
		
			
			$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			
			$userpic = rand(1000,1000000).".".$imgExt;
			
			if(in_array($imgExt, $valid_extensions)){			
				
				if($imgSize < 100000)			{
					move_uploaded_file($tmp_dir,$upload_dir.$userpic);
				}
				else{
					$errMSG = "Sorry, your file is too large.";
				}
			}
			else{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}
		}
		
		
		// if no error occured, continue ....
		if(!isset($errMSG))
		{
			$stmt = $DB_con->prepare('INSERT INTO images(imuid,  userPic, ip_address) VALUES(:uid, :upic, :uip)');
			$stmt->bindParam(':uid',$userid);
			$stmt->bindParam(':upic',$userpic);
			$stmt->bindParam(':uip',$ip_address);
						
			if($stmt->execute())
			{
				$successMSG = "Succesfully inserted ...";
				header("refresh:1;index.php"); // redirects image view page after 5 seconds.
			}
			else
			{
				$errMSG = "error while inserting....";
			}
		}
	}
?>

<!DOCTYPE html>
<html lang='en'>
<head>	
	<title>Welcome -
            <?php echo $Name; ?>
    </title>
	<link href='css/bootstrap.css' 			rel='stylesheet'>			</link>
	<link id='themeLink' href='css/themes/blue.css' rel='stylesheet'></link>		
    <script src='js/jquery.min.js' type='text/javascript'></script>
    <script src='js/bootstrap.min.js'></script>	
	<link rel='stylesheet' href='css/font-awesome.min.css' />			
</head>
<body>		
	<div class='container'>
		<div class='row'>
			<div class='col-sm-12'>
				<ul class='zetta-menu'>
					<li><a href='../index'> Main Home</a></li>
					<li><a href='index'> Home</a></li>
					<li><a href='profile'> Update Profile </a></li>
					<li><a href=''> Download CV</a></li>
					<li class='zm-right-item zm-right-align'>
						<a>                                
						<?php                                         
									
							if($pid!=NULL and $pass!=NULL)
								{
								   echo $Name;
								}          
						?> 

						</a>									
						
					</li>
					<li><a href=''> Contact </a></li>
				</ul>
			</div>
		</div>
	</div>


	<div class='container'>
		
	<div class='red' style='font-size:17px; font-weight:bold; border:1px solid #ed0101; padding:5px; margin-bottom:15px'>
		N.B:
		<br>
			<ol class='red'>
				<li class='red'> Use (Width 220 x Height 260) Pixels Image. </li>
				<li> Image size should be less than 100KB. </li>
				<li> Use only JPG, JPEG, PNG & GIF files are allowed.</li>
			</ol>
							
	</div>	
		
		
		<?php
		if(isset($errMSG))
		{
				?>
				<div class='alert alert-danger'>
					<span class='glyphicon glyphicon-info-sign'></span> <strong><?php echo $errMSG; ?></strong>
				</div>
				<?php
		}
		else if(isset($successMSG))
		{
			?>
			<div class='alert alert-success'>
				  <strong><span class='glyphicon glyphicon-info-sign'></span> <?php echo $successMSG; ?></strong>
			</div>
			<?php
		}
		?>   

		<form method='post'  enctype='multipart/form-data' class='form-horizontal'>	    
			<div class='col-sm-6'>	
				 
				
				<div>					
					<input class='input-group' type='file' name='user_image' accept='image/*' />
				</div>  <br>
							
				<div>
					<div colspan='6'>
					<button type='submit' name='btnsave' class='btn btn-block btn-primary'>
					<span class='glyphicon glyphicon-save'></span> &nbsp; Save
					</button>
					</div>
				</div>   
			</div>    
		</form>
	</div>
<script src='bootstrap/js/bootstrap.min.js'></script>


</body>
</html>