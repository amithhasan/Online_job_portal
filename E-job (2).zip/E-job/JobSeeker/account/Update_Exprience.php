<?php require_once("../session.php"); ?>
<?php require_once("../functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header("Location: ../../login");
	
	
	}	

    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "e-job"; 


	$conn = mysqli_connect($servername, $username, $password, $dbname);

	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$skill=$_POST['skill'];
	
	$company		=$_POST['company'];
	$designetion	=$_POST['designetion'];
	$address		=$_POST['address'];
	$duration		=$_POST['duration'];
	$mobile			=$_POST['mobile'];
	
	$company1		=$_POST['company1'];
	$designetion1	=$_POST['designetion1'];
	$address1		=$_POST['address1'];
	$duration1		=$_POST['duration1'];
	$mobile1		=$_POST['mobile1'];
	
	$company2		=$_POST['company2'];
	$designetion2	=$_POST['designetion2'];
	$address2		=$_POST['address2'];
	$duration2		=$_POST['duration2'];
	$mobile2		=$_POST['mobile2'];
	
	
	
	
	$sql= " UPDATE `experience` SET 
	`skill` = '$skill', 	`company` ='$company',	`designetion` ='$designetion',	`address` ='$address',	`duration` ='$duration',	`mobile` ='$mobile',
	`company1`='$company1',	`designetion1`='$designetion1',	`address1`='$address1',	`duration1`='$duration1',	`mobile1`='$mobile1',
	`company2`='$company2',	`designetion2`='$designetion2',	`address2`='$address2',	`duration2`='$duration2',	`mobile2`='$mobile2' 
	WHERE  exuid='".$_SESSION['user_id']."'";
	
	
	if (mysqli_query($conn, $sql)) 
	{
		echo "<script>alert('Successfully Updated!'); window.location='profile'</script>";
	} 
	else 
	{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?> 
