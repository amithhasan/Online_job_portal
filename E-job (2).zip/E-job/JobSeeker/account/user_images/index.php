<?php 
    //header('Content-type: user_images/jpg');
    
if(isset($_GET['image'])) 
    {
        $image=$_GET['image'];
    
        $image_size=getimagesize($image);
        
         $image_width=$image_size[0];
         $image_height=$image_size[1];
    
    
    echo $new_size=($image_width+$image_height)/($image_width *($image_height/45));
    
    
    
    }

?>