<?php require_once 'config.php'; ?>
<?php require_once('../session.php'); ?>
<?php require_once('../functions.php'); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('Location: ../../Login');
	
	
	}	
?>
<!DOCTYPE html>
<html lang='en'>
<head>
	
	<title>Welcome -
            <?php echo $Name; ?>
    </title>
	<link href='css/bootstrap.css' 			rel='stylesheet'>			</link>
	<link href='css/style.css' 				rel='stylesheet'>		    </link>
	<link id='themeLink' href='css/themes/blue.css' rel='stylesheet'></link>
	<link type='text/css' href='css/tabbed.css' rel='stylesheet' </link>
	<link media='screen' href='css/blue.css' type='text/css' rel='stylesheet'> </link>
	
	
    <script src='js/jquery.min.js' type='text/javascript'></script>
    <script src='js/bootstrap.min.js'></script>
	
    <script src='same.js'></script>
	
	<link rel='stylesheet' href='css/bootstrap-datepicker3.css'/>	
	<link rel='stylesheet' href='css/font-awesome.min.css' />	
	<script type='text/javascript' src='js/formden.js'></script>
	<script type='text/javascript' src='js/bootstrap-datepicker.min.js'></script>
	
	
</head>
<body>
		
<div class='container'>
	<div class='row'>
		<div class='col-sm-12'>
			<ul class='zetta-menu'>
				<li><a href='../index'> Main Home</a></li>
				<li><a href='index'> Home</a></li>
				<li><a href='profile'> Update Profile </a></li>
				<li><a href=''> Download CV</a></li>
				<li class='zm-right-item zm-right-align'>
					<a >                                
								<?php                                         
                                
								 if($pid!=NULL and $pass!=NULL)
                                {
                                   echo $Name;
                                }
                                else
                                    echo 'Not in';                                                               

                                ?> &nbsp;<span class='caret'></span>

                    </a>
					
					
					<ul><li><a href='../logout'>Logout</a></li></ul>
				</li>
				<li><a href=''> Contact </a></li>
			</ul>
		</div>
	</div>
</div>
			
<div class='container'>
      <ul class='nav nav-tabs'>
        <li class='active'><a href='#home'>BASIC INFO</a></li>
        <li><a href='#menu1'>EDUCATION & TRAINING</a></li>
        <li><a href='#menu2'>EXPERIENCE</a></li>
        <li><a href='#menu3'>REFERANCE</a></li>
        <li><a href='#menu4'>Photo</a></li>
      </ul>
    <div class='tab-content'>
	  <hr>
      <p class='act'><b>Active Tab</b>: <span></span></p>
      <p class='prev'><b>Previous Tab</b>: <span></span></p>
	  <hr> 
	  
<?php
			$query  = "SELECT * FROM basic_info where uid='".$_SESSION['user_id']."' ";
			$query_data = mysqli_query($con, $query);
			$row = mysqli_fetch_array($query_data);
	
						
	if ($row['uid']!=null)  //for update that user  input information
	
	{ 
        echo"<div id='home'  class='tab-pane fade in active'>
	  <div id='content'>		
		<form   class='form-horizontal' action='update_basic.php' method='post' role='form' > 
			<h4> Basic Information </h4>
		 
			<div class='form-group'>
			  <label class='col-sm-4'>Name  </label>
			  <div class='col-sm-8'>
				<input type='text' value='$row[name]' name='name' class='form-control' >
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Father Name  </label>
			  <div class='col-sm-8'>
				<input type='text' name='fname' class='form-control'  value='$row[fname]' disabled/>
			  </div>
			</div>
			<div class='form-group'>
			  <label class='col-sm-4'>Father Occupation </label>
			  <div class='col-sm-8'>
				<input type='text' name='foccup' class='form-control'  value='$row[foccup]' >
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Mother Name  </label>
			  <div class='col-sm-8'>
				<input type='text' name='mname' class='form-control' value='$row[mname]' disabled>
			  </div>
			</div>
			<div class='form-group'>
			  <label class='col-sm-4'>Mother Occupation </label>
			  <div class='col-sm-8'>
				<input type='text' name='moccup' class='form-control'  value='$row[moccup]'>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Gender  </label>
			  <div class='col-sm-8 '>
				<select class='form-control' name='gender' disabled >		
					<option > $row[gender] </option>
					 					   
				</select>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Email  </label>
			  <div class='col-sm-8'>
				<input type='email' name='email' class='form-control' value='$row[email]' disabled>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Mobile </label>
			  <div class='col-sm-8'>
				<input type='text' name='mobile' class='form-control' value='$row[mobile]'>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Home Phone </label>
			  <div class='col-sm-8'>
				<input type='text' name='hmobile' class='form-control' value='$row[hmobile]' >
			  </div>
			</div>
			
		<div class='form-group bootstrap-iso'>
			  <label class='col-sm-4'>Date of Birth  </label>
			<div class='col-sm-8'>				
					<div class='input-group' >
						<input class='form-control'  name='bdate' value='$row[bdate]' disabled/>
						<span class='input-group-addon'>
							<span class='glyphicon glyphicon-calendar'></span>
						</span>
					</div>
				
			</div>
		</div>

			
			
			<div class='form-group'>
			  <label class='col-sm-4'>Blood Group  </label>
			  <div class='col-sm-8 '>
				<select class='form-control'  name='blood' disabled >
						<option > $row[blood]</option>
						 					  												 					   
				</select>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Religion </label>
			  <div class='col-sm-8'>
				<input type='text' name='religion' class='form-control' value='$row[religion]' disabled>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Nationality </label>
			  <div class='col-sm-8'>
				<input type='text' name='nationality' class='form-control' value='$row[nationality]' disabled>
			  </div>
			</div>
			
		
		<div class='form-group'>
			  <label class='col-sm-4'>National ID </label>
				<div class='col-sm-3'>				
					<select onchange='yesnoCheck1(this);' name='nid' class='form-control' >
						
						<option value='$row[nid]'> $row[nid]</option>
						<option value='Yes'>Yes</option>
					</select>				
				</div>		
				
				<div class='col-sm-4' id='amit' style='display: none;'>				
					Nid Number :			 
					<input type='text' required name='nino' value='$row[nino]'>				  					
				</div>
		</div>		
			
		<script>
				function yesnoCheck1(that) 
				{
					if (that.value == 'Yes') 
					{
						
						document.getElementById('amit').style.display = 'block';
					} else 
					{
						document.getElementById('amit').style.display = 'none';
					}
				}
		</script>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Marital Status </label>
				<div class='col-sm-3'>				
					<select onchange='yesnoCheck(this);' name='mstatus' class='form-control' >
						<option value='$row[mstatus]'>$row[mstatus]</option>
						<option value='Single'> Single</option>
						<option value='Marride'> Marride</option>
					</select>
				
				</div>
				
				<div class='col-sm-4' id='ifYes' style='display: none;'>				
					Spouse Name 
					<input type='text' name='spouse' id='car' value='$row[spouse]' >

				</div>
			</div>
			
				
			<script>
				function yesnoCheck(that) {
					if (that.value == 'Marride') {
						
						document.getElementById('ifYes').style.display = 'block';
					} else {
						document.getElementById('ifYes').style.display = 'none';
					}
				}
			</script>
			
			
			
			<div class='form-group'>
			  <label class='col-sm-4'>Height </label>
			  <div class='col-sm-8'>
				<input type='text' name='height' class='form-control' value='$row[height]'  >
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Weight </label>
			  <div class='col-sm-8'>
				<input type='text' name='weight' class='form-control' value='$row[weight]'  >
			  </div>
			</div>
			
		<h4> Address </h4>
		
			<div class='row '>						
				<div class='col-sm-6 left'> 
					<h4> Parmanent Address </h4>
																										
						Village/Word No. 
						<input type='text'  name='vill'  class='form-control' value='$row[vill]' disabled/>
										
						P.O/Post Code  
						<input type='text'  name='po'    class='form-control' value='$row[po]' disabled/>
										 
										 
						Thana   
						<input type='text'  name='thana' class='form-control' value='$row[thana]' disabled/>
										 
										 
						Dist   
						<input type='text'  name='dist'  class='form-control' value='$row[dist]' disabled/>									 
										
				</div>
				<div class='col-sm-6 right'> 
					<h4> Present Address </h4>
									 
					Village/Word No. 
					<input type='text'  name='pvill'  class='form-control' value='$row[pvill]'/> 
										 
					P.O/Post Code   
					<input type='text'  name='ppo'  class='form-control' value='$row[ppo]'/> 
										 
					Thana 
					<input type='text'  name='pthana'  class='form-control' value='$row[pthana]'/> 
										 
					Dist :
									
					<select name='pdist' class='form-control' id='sel1'>				
					   <option value='$row[pdist]'>$row[pdist]</option>
						<option value='Dhaka'>Dhaka</option>
                        <option value='Faridpur'>Faridpur</option>
                        <option value='Gazipur'>Gazipur</option>
                        <option value='Gopalganj'>Gopalganj</option>
                        <option value='Jamalpur'>Jamalpur</option>
                        <option value='Kishoreganj'>Kishoreganj</option>
                        <option value='Madaripur'>Madaripur</option>
                        <option value='Manikganj'>Manikganj</option>
                        <option value='Munshiganj'>Munshiganj</option>
                        <option value='Mymensingh'>Mymensingh </option>
                        <option value='Narayanganj'>Narayanganj </option>
                        <option value='Narsingdi'>Narsingdi </option>
                        <option value='Netrakona'>Netrakona </option>
                        <option value='Rajbari'>Rajbari </option>
                        <option value='Shariatpur'>Shariatpur </option>
                        <option value='Sherpur'>Sherpur </option>
                        <option value='Tangail'>Tangail </option>
                        <option value='Barguna'>Barguna </option>
                        <option value='Barisal'>Barisal </option>
                        <option value='Bhola'>Bhola </option>
                        <option value='Jhalokati'>Jhalokati </option>
                        <option value='Patuakhali'>Patuakhali </option>
                        <option value='Pirojpur'>Pirojpur </option>
                        <option value='Bandarban'>Bandarban </option>
                        <option value='Brahmanbaria'>Brahmanbaria </option>
                        <option value='Chandpur'>Chandpur </option>
                        <option value='Chittagong'>Chittagong </option>
                        <option value='Comilla'>Comilla </option>
                        <option value='CoxBajar'>Cox&#039;s Bazar </option>
                        <option value='Feni'>Feni </option>
                        <option value='Khagrachhari'>Khagrachhari </option>
                        <option value='Lakshmipur'>Lakshmipur </option>
                        <option value='Noakhali'>Noakhali </option>
                        <option value='Rangamati'>Rangamati </option>
                        <option value='Bagerhat'>Bagerhat </option>
                        <option value='Chuadanga'>Chuadanga </option>
                        <option value='Jessore'>Jessore </option>
                        <option value='Jhenaidah'>Jhenaidah </option>
                        <option value='Khulna'>Khulna </option>
                        <option value='Kushtia'>Kushtia </option>
                        <option value='Magura'>Magura </option>
                        <option value='Meherpur'>Meherpur </option>
                        <option value='Narail'>Narail </option>
                        <option value='Satkhira'>Satkhira </option>
                        <option value='Bogra'>Bogra </option>
                        <option value='Joypurhat'>Joypurhat </option>
                        <option value='Naogaon'>Naogaon </option>
                        <option value='Natore'>Natore </option>
                        <option value='Nawabganj'>Nawabganj </option>
                        <option value='Pabna'>Pabna </option>
                        <option value='Rajshahi'>Rajshahi </option>
                        <option value='Sirajganj'>Sirajganj </option>
                        <option value='Dinajpur'>Dinajpur </option>
                        <option value='Gaibandha'>Gaibandha </option>
                        <option value='Kurigram'>Kurigram </option>
                        <option value='Lalmonirhat'>Lalmonirhat </option>
                        <option value='Nilphamari'>Nilphamari </option>
                        <option value='Panchagarh'>Panchagarh </option>
                        <option value='Rangpur'> Rangpur </option>
                        <option value='Thakurgaon'> Thakurgaon </option>
                        <option value='Habiganj'> Habiganj </option>
                        <option value='Moulvibazar'> Moulvibazar </option>
                        <option value='Sunamganj'> Sunamganj </option>
                        <option value='Sylhet'> Sylhet </option>                                              
                    </select>
						
				</div>					
			</div>
			<br>
			<div class='form-group'>
				<button type='submit' class='btn btn-block btn-primary' name='Submit'>Submit</button>
			</div>
		
        </form>
		           
		</div>
		</div>";
	}
	
	
else
	{
        echo"<div id='home'  class='tab-pane fade in active'>
	  <div id='content'>		
		<form   class='form-horizontal' action='basic.php' method='post' role='form' > 
			<h4> Basic Information </h4>
		 
			<div class='form-group'>
			  <label class='col-sm-4'>Name <span class='red' >*</span> </label>
			  <div class='col-sm-8'>
				<input type='text'  name='name' class='form-control' >
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Father Name <span class='red' >*</span> </label>
			  <div class='col-sm-8'>
				<input type='text' name='fname' class='form-control' required placeholder='Father Name'>
			  </div>
			</div>
			<div class='form-group'>
			  <label class='col-sm-4'>Father Occupation </label>
			  <div class='col-sm-8'>
				<input type='text' name='foccup' class='form-control'  placeholder='Father Occupation'>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Mother Name <span class='red' >*</span> </label>
			  <div class='col-sm-8'>
				<input type='text' name='mname' class='form-control' required placeholder='Mother Name'>
			  </div>
			</div>
			<div class='form-group'>
			  <label class='col-sm-4'>Mother Occupation </label>
			  <div class='col-sm-8'>
				<input type='text' name='moccup' class='form-control'  placeholder='Mother Occupation'>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Gender <span class='red' >*</span> </label>
			  <div class='col-sm-8 '>
				<select class='form-control' name='gender' required >
					<option value='' selected='selected'>----Select---- </option>
					<option value='Male' > Male </option>
					<option value='Female'> Female </option> 					   
				</select>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Email <span class='red' >*</span> </label>
			  <div class='col-sm-8'>
				<input type='email' name='email' class='form-control' required placeholder='Email'>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Mobile <span class='red' >*</span> </label>
			  <div class='col-sm-8'>
				<input type='text' name='mobile' class='form-control' required placeholder='Mobile Number'>
			  </div>
			</div>
			<div class='form-group'>
			  <label class='col-sm-4'>Home Phone </label>
			  <div class='col-sm-8'>
				<input type='text' name='hmobile' class='form-control'  >
			  </div>
			</div>
			
		<div class='form-group bootstrap-iso'>
			  <label class='col-sm-4'>Date of Birth <span class='red' >*</span> </label>
			<div class='col-sm-8'>				
					<div class='input-group' id='datetimepicker'>
						<input class='form-control' id='date' required name='bdate' placeholder='MM/DD/YYYY' type='text'/>
						<span class='input-group-addon'>
							<span class='glyphicon glyphicon-calendar'></span>
						</span>
					</div>
				
			</div>
		</div>
			
		<script>
			$(document).ready(function(){
				var date_input=$('input[name=bdate]'); 
				var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() :'body';
				date_input.datepicker({
					format: 'mm/dd/yyyy',
					container: container,
					todayHighlight: true,
					autoclose: true,
				})
			})
		</script>
			
			
			<div class='form-group'>
			  <label class='col-sm-4'>Blood Group <span class='red' >*</span> </label>
			  <div class='col-sm-8 '>
				<select class='form-control'  name='blood' required >
						<option value='' selected='selected'>---Select--- </option>
						<option value='A+' > A+ </option>
						<option value='AB+'> AB+ </option> 					   
						<option value='AB-'> AB- </option> 					  												 					   
						<option value='B-' > B- </option> 					  												 					   
						<option value='B+' > B+ </option> 					  												 					   
						<option value='0+' > O+ </option> 					  												 					   
						<option value='0-' > O- </option> 					  												 					   
				</select>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Religion <span class='red' >*</span></label>
			  <div class='col-sm-8'>
				<input type='text' name='religion' class='form-control' required >
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Nationality <span class='red' >*</span></label>
			  <div class='col-sm-8'>
				<input type='text' name='nationality' class='form-control' required >
			  </div>
			</div>
			
		
			
		<div class='form-group'>
			  <label class='col-sm-4'>National ID <span class='red' >*</span></label>
				<div class='col-sm-3'>				
					<select onchange='yesnoCheck1(this);' name='nid' class='form-control' required>
						<option value=''>----Select----</option>
						<option value='No'> No</option>
						<option value='Yes'> Yes</option>
					</select>
				
				</div>				
				<div class='col-sm-4' id='amit1' style='display: none;'>				
					NID  Number  :			 
					<input type='text' required name='nino' >				  					
				</div>
			</div>							
		<script>
				function yesnoCheck1(that) {
					if (that.value == 'Yes') {
						
						document.getElementById('amit1').style.display = 'block';
					} else {
						document.getElementById('amit1').style.display = 'none';
					}
				}
		</script>	
						
			
			<div class='form-group'>
			  <label class='col-sm-4'>Marital Status <span class='red' >*</span></label>
				<div class='col-sm-3'>				
					<select onchange='yesnoCheck(this);' name='mstatus' class='form-control' required>
						<option value=''>----Select----</option>
						<option value='Single'> Single</option>
						<option value='Marride'> Marride</option>
					</select>
				
				</div>				
				<div class='col-sm-5' id='ifYes2' style='display: none;'>				
					Spouse Name: 				 
					<input type='text' name='spouse' id='car'  >				  					
				</div>
			</div>							
			<script>
				function yesnoCheck(that) {
					if (that.value == 'Marride') {
						
						document.getElementById('ifYes2').style.display = 'block';
					} else {
						document.getElementById('ifYes2').style.display = 'none';
					}
				}
			</script>
			
			
			
			<div class='form-group'>
			  <label class='col-sm-4'>Height <span class='red' >*</span></label>
			  <div class='col-sm-8'>
				<input type='text' name='height' class='form-control' required placeholder='Example: 5.7'''  >
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Weight <span class='red' >*</span></label>
			  <div class='col-sm-8'>
				<input type='text' name='weight' class='form-control' required  >
			  </div>
			</div>
			
		<h4> Address </h4>
		
			<div class='row '>						
				<div class='col-sm-6 left'> 
					<h4> Parmanent Address </h4>
						<br>																				
						Village/Word No. <span class='red' >*</span>
						<input type='text' required name='vill'  class='form-control' placeholder='ABC(1)'/>
										
						P.O/Post Code <span class='red' >*</span>  
						<input type='text' required name='po'  class='form-control' placeholder='ABC(1234)'/>
										 
										 
						Thana <span class='red' >*</span>  
						<input type='text' required name='thana'  class='form-control'/>
										 
										 
						Dist <span class='red' >*</span>  
						 
						
					<select name='dist' required class='form-control' id='sel1'>
                        <option value='' selected='selected'>Any Where</option>
                        <option value='Dhaka'>Dhaka</option>
                        <option value='Faridpur'>Faridpur</option>
                        <option value='Gazipur'>Gazipur</option>
                        <option value='Gopalganj'>Gopalganj</option>
                        <option value='Jamalpur'>Jamalpur</option>
                        <option value='Kishoreganj'>Kishoreganj</option>
                        <option value='Madaripur'>Madaripur</option>
                        <option value='Manikganj'>Manikganj</option>
                        <option value='Munshiganj'>Munshiganj</option>
                        <option value='Mymensingh'>Mymensingh </option>
                        <option value='Narayanganj'>Narayanganj </option>
                        <option value='Narsingdi'>Narsingdi </option>
                        <option value='Netrakona'>Netrakona </option>
                        <option value='Rajbari'>Rajbari </option>
                        <option value='Shariatpur'>Shariatpur </option>
                        <option value='Sherpur'>Sherpur </option>
                        <option value='Tangail'>Tangail </option>
                        <option value='Barguna'>Barguna </option>
                        <option value='Barisal'>Barisal </option>
                        <option value='Bhola'>Bhola </option>
                        <option value='Jhalokati'>Jhalokati </option>
                        <option value='Patuakhali'>Patuakhali </option>
                        <option value='Pirojpur'>Pirojpur </option>
                        <option value='Bandarban'>Bandarban </option>
                        <option value='Brahmanbaria'>Brahmanbaria </option>
                        <option value='Chandpur'>Chandpur </option>
                        <option value='Chittagong'>Chittagong </option>
                        <option value='Comilla'>Comilla </option>
                        <option value='CoxBajar'>Cox&#039;s Bazar </option>
                        <option value='Feni'>Feni </option>
                        <option value='Khagrachhari'>Khagrachhari </option>
                        <option value='Lakshmipur'>Lakshmipur </option>
                        <option value='Noakhali'>Noakhali </option>
                        <option value='Rangamati'>Rangamati </option>
                        <option value='Bagerhat'>Bagerhat </option>
                        <option value='Chuadanga'>Chuadanga </option>
                        <option value='Jessore'>Jessore </option>
                        <option value='Jhenaidah'>Jhenaidah </option>
                        <option value='Khulna'>Khulna </option>
                        <option value='Kushtia'>Kushtia </option>
                        <option value='Magura'>Magura </option>
                        <option value='Meherpur'>Meherpur </option>
                        <option value='Narail'>Narail </option>
                        <option value='Satkhira'>Satkhira </option>
                        <option value='Bogra'>Bogra </option>
                        <option value='Joypurhat'>Joypurhat </option>
                        <option value='Naogaon'>Naogaon </option>
                        <option value='Natore'>Natore </option>
                        <option value='Nawabganj'>Nawabganj </option>
                        <option value='Pabna'>Pabna </option>
                        <option value='Rajshahi'>Rajshahi </option>
                        <option value='Sirajganj'>Sirajganj </option>
                        <option value='Dinajpur'>Dinajpur </option>
                        <option value='Gaibandha'>Gaibandha </option>
                        <option value='Kurigram'>Kurigram </option>
                        <option value='Lalmonirhat'>Lalmonirhat </option>
                        <option value='Nilphamari'>Nilphamari </option>
                        <option value='Panchagarh'>Panchagarh </option>
                        <option value='Rangpur'> Rangpur </option>
                        <option value='Thakurgaon'> Thakurgaon </option>
                        <option value='Habiganj'> Habiganj </option>
                        <option value='Moulvibazar'> Moulvibazar </option>
                        <option value='Sunamganj'> Sunamganj </option>
                        <option value='Sylhet'> Sylhet </option>
                    </select>
						



						
										
				</div>
				<div class='col-sm-6 right'> 
					<h4> Present Address </h4>
					
					<input type='checkbox' name='billingtoo' onclick='FillBilling(this.form)'>
					<em> Address are the same.</em><P>
									 
					Village/Word No. <span class='red' >*</span>
					<input type='text' required name='pvill'  class='form-control'/> 
										 
					P.O/Post Code <span class='red' >*</span>  
					<input type='text' required name='ppo'  class='form-control' /> 
										 
					Thana <span class='red' >*</span> 
					<input type='text' required name='pthana'  class='form-control'/> 
										 
					Dist <span class='red' >*</span> 
					 
					
					<select name='pdist' required class='form-control' id='sel1'>
                        <option value='' selected='selected'>Any Where</option>
                        <option value='Dhaka'>Dhaka</option>
                        <option value='Faridpur'>Faridpur</option>
                        <option value='Gazipur'>Gazipur</option>
                        <option value='Gopalganj'>Gopalganj</option>
                        <option value='Jamalpur'>Jamalpur</option>
                        <option value='Kishoreganj'>Kishoreganj</option>
                        <option value='Madaripur'>Madaripur</option>
                        <option value='Manikganj'>Manikganj</option>
                        <option value='Munshiganj'>Munshiganj</option>
                        <option value='Mymensingh'>Mymensingh </option>
                        <option value='Narayanganj'>Narayanganj </option>
                        <option value='Narsingdi'>Narsingdi </option>
                        <option value='Netrakona'>Netrakona </option>
                        <option value='Rajbari'>Rajbari </option>
                        <option value='Shariatpur'>Shariatpur </option>
                        <option value='Sherpur'>Sherpur </option>
                        <option value='Tangail'>Tangail </option>
                        <option value='Barguna'>Barguna </option>
                        <option value='Barisal'>Barisal </option>
                        <option value='Bhola'>Bhola </option>
                        <option value='Jhalokati'>Jhalokati </option>
                        <option value='Patuakhali'>Patuakhali </option>
                        <option value='Pirojpur'>Pirojpur </option>
                        <option value='Bandarban'>Bandarban </option>
                        <option value='Brahmanbaria'>Brahmanbaria </option>
                        <option value='Chandpur'>Chandpur </option>
                        <option value='Chittagong'>Chittagong </option>
                        <option value='Comilla'>Comilla </option>
                        <option value='CoxBajar'>Cox&#039;s Bazar </option>
                        <option value='Feni'>Feni </option>
                        <option value='Khagrachhari'>Khagrachhari </option>
                        <option value='Lakshmipur'>Lakshmipur </option>
                        <option value='Noakhali'>Noakhali </option>
                        <option value='Rangamati'>Rangamati </option>
                        <option value='Bagerhat'>Bagerhat </option>
                        <option value='Chuadanga'>Chuadanga </option>
                        <option value='Jessore'>Jessore </option>
                        <option value='Jhenaidah'>Jhenaidah </option>
                        <option value='Khulna'>Khulna </option>
                        <option value='Kushtia'>Kushtia </option>
                        <option value='Magura'>Magura </option>
                        <option value='Meherpur'>Meherpur </option>
                        <option value='Narail'>Narail </option>
                        <option value='Satkhira'>Satkhira </option>
                        <option value='Bogra'>Bogra </option>
                        <option value='Joypurhat'>Joypurhat </option>
                        <option value='Naogaon'>Naogaon </option>
                        <option value='Natore'>Natore </option>
                        <option value='Nawabganj'>Nawabganj </option>
                        <option value='Pabna'>Pabna </option>
                        <option value='Rajshahi'>Rajshahi </option>
                        <option value='Sirajganj'>Sirajganj </option>
                        <option value='Dinajpur'>Dinajpur </option>
                        <option value='Gaibandha'>Gaibandha </option>
                        <option value='Kurigram'>Kurigram </option>
                        <option value='Lalmonirhat'>Lalmonirhat </option>
                        <option value='Nilphamari'>Nilphamari </option>
                        <option value='Panchagarh'>Panchagarh </option>
                        <option value='Rangpur'> Rangpur </option>
                        <option value='Thakurgaon'> Thakurgaon </option>
                        <option value='Habiganj'> Habiganj </option>
                        <option value='Moulvibazar'> Moulvibazar </option>
                        <option value='Sunamganj'> Sunamganj </option>
                        <option value='Sylhet'> Sylhet </option>
                    </select>
					
						
				</div>					
			</div>
				<br>
				<div class='form-group'>
					<button type='submit' class='btn btn-block btn-primary' name='Submit'>Submit</button>
				</div>
		
			</form>
		           
			</div>
		</div>";
	}
	
?>
	
	
<?php
			$query  = "SELECT * FROM education where euid='".$_SESSION['user_id']."'";
			$query_data = mysqli_query($con, $query);
			$row = mysqli_fetch_array($query_data);
	
						
	if ($row['euid']!=null) 
	
	{ 
        echo"<div id='menu1' class='tab-pane fade'>         
		  <div id='content'>
			<h4> Educational Information </h4>
			<form  action='update_education.php' method='post' accept-charset='UTF-8'>	
				<table class='table' style='font-size: 14px; ' >
					<tbody>
					<tr>
								<th> Degree </th>
								<th> Board/University </th>
								<th width='250'> Institute Name</th>
								<th> Group/Major </th>
								<th width='100'> Result </th>
								<th width='80'> Passing Year </th>
								
					</tr>
					<tr>
						<td>								
							<select name='ssc'  class='form-control' disabled >
								<option>$row[ssc]</option>								
							</select> 								
						</td>
						
						<td> 
							<select name='sscb' class='form-control' disabled>
								<option > $row[sscb]</option>								
							</select>
						</td>
						
						<td> 
							<input type='text' value='$row[sscinst]' disabled name='sscinst'  class='form-control'/> 
						</td>
								
						<td>
							<select name='sgroup' disabled class='form-control' >
								<option> $row[sgroup]</option>
							</select> 
						</td>
						
						<td> 
							<input type='text' value='$row[sscgpa]' name='sscgpa' disabled   class='form-control'/>
						</td>
						<td> 
							<input type='text' value='$row[sscpy]' name='sscpy' disabled  class='form-control'/>
						</td>
								
					</tr>
					
					<tr>
						<td> 
								
							<select name='hsc' class='form-control' disabled>
								<option >$row[hsc] </option>	
							</select>
								
						</td>
						<td> 
						
							<select name='hscb' class='form-control' disabled>
								<option > $row[hscb]</option>										
							</select> 
						
						</td>
						
						<td> 
							<input type='text' value='$row[hscinst]' name='hscinst' disabled  class='form-control'/> 
						</td>
						
						<td> 
							<select class='form-control' name='hgroup' disabled>
								<option > $row[hgroup]</option>									   
							</select>
						</td>
						<td> 
							<input type='text' value='$row[hscgpa]' name='hscgpa' disabled   class='form-control'/> 
						</td>
						<td> 
							<input type='text' value='$row[hscpy]' name='hscpy' disabled class='form-control'/> 
						</td>
								
								
					</tr>
					<tr>
						<td> 
							<input type='text' value='$row[honors]' disabled name='honors'  class='form-control'/> 
						</td>
						<td> 
							<input type='text' value='$row[honorsb]' disabled name='honorsb'  class='form-control'/> 
						</td>
						<td> 
							<input type='text' value='$row[honinst]' disabled name='honinst'  class='form-control'/>
						</td>
						<td> 
							<select class='form-control' name='honsub' disabled >
								<option > $row[honsub] </option>					   
							</select>
						</td>
						<td> 
							<input type='text' value='$row[honcgpa]' name='honcgpa'    class='form-control'/> 
						</td>
						<td> 
							<input type='text' value='$row[honpy]' name='honpy'  class='form-control'/> 
						</td>						
								
					</tr>
					
					<tr>
						<td> 
							<input type='text' value='$row[mastars]'  placeholder='Mastars'  name='mastars'  class='form-control'/> 
						</td>
						<td> 
							<input type='text' value='$row[mastarsb]' name='mastarsb'  class='form-control'/> 
						</td>
						<td> 
							<input type='text' value='$row[mastinst]' name='mastinst'  class='form-control'/> 
						</td>
						<td> 
							<select class='form-control' name='mastsub' >
								<option value='$row[mastsub]' selected='selected'>$row[mastsub] ------  </option>
								<option value='Bangla' > Bangla </option>
								<option value='BBA' > BBA </option>
								<option value='Chymestry' > Chymestry </option>
								<option value='CSE'> CSE </option> 					   
								<option value='Civil'> Civil </option> 					   
								<option value='English'> English </option> 					   
								<option value='Economics'> Economics </option> 					   
								<option value='EEE'> EEE </option> 					   
								<option value='ICE'> ICE </option> 					   
								<option value='Pharmacy'> Pharmacy </option> 					   
								<option value='Mathametics'> Mathametics </option> 					   
								<option value='Mechanical'> Mechanical </option> 					   
								<option value='Political Science'> Political Science </option> 					   
								<option value='Journalism'> Journalism </option> 					   
								<option value='Law'> Law </option> 					   
								<option value='Islamic History'> Islamic History </option> 					   
								<option value='Statistic '> Statistic </option> 					   
							</select> 
						</td>
						<td> 
							<input type='text' value='$row[mastcgpa]' name='mastcgpa'    class='form-control'/> 
						</td>
						<td> 
							<input type='text' value='$row[mastpy]' name='mastpy'  class='form-control'/> 
						</td>						
								
					</tr>
				</tbody>
				</table>
					
					<h4> Training Information </h4>
					<table class='table ' style='font-size: 14px; font-weight: 500'>
						<tbody>
							<tr>
								<th> Training Title </th>
								<th  width='120'> Duration </th>
								<th> Institute </th>
								<th  width='135'> Institute Contact </th>
								<th> Institute Address </th>
								
								
							</tr>
							<tr>
								<td> <input type='text' value='$row[tname]' name='tname'  class='form-control'/> </td>
								<td> <input type='text' value='$row[tdur]' 	name='tdur'  class='form-control'/> </td>
								<td> <input type='text' value='$row[tinst]' name='tinst'  class='form-control'/> </td>
								<td> <input type='text' value='$row[tinstcont]' name='tinstcont'  class='form-control'/> </td>
								<td> <input type='text' value='$row[tinstadd]' 	name='tinstadd'  class='form-control'/> </td>								
								
							</tr>
							<tr>
								<td> <input type='text' value='$row[tname2]' 	name='tname2'  class='form-control'/> </td>
								<td> <input type='text' value='$row[tdur2]' 	name='tdur2'  class='form-control'/> </td>
								<td> <input type='text' value='$row[tinst2]' 	name='tinst2'  class='form-control'/> </td>
								<td> <input type='text' maxlength='11' value='$row[tinstcont2]'name='tinstcont2'  class='form-control'/> </td>
								<td> <input type='text' value='$row[tinstadd2]' name='tinstadd2'  class='form-control'/> </td>								
								
							</tr>
						</tbody>
					</table>
					<div class='form-group'>
						<button type='submit' class='btn btn-block btn-primary' name='Submit'>Submit</button>
					</div>
				</form>
					
			</div>		
		 </div>";
	}
	
	
else
	
	{ 
        echo"<div id='menu1' class='tab-pane fade'>         
		  <div id='content'>
			<h4> Educational Information </h4>
			<form  action='education.php' method='post' accept-charset='UTF-8'>	
				<table class='table' style='font-size: 14px; ' >
					<tbody>
					<tr>
								<th> Degree </th>
								<th> Board/University </th>
								<th width='250'> Institute Name</th>
								<th> Group/Major </th>
								<th width='100'> Result </th>
								<th width='80'> Passing Year </th>
								
					</tr>
					<tr>
						<td>								
							<select name='ssc' required class='form-control' >
								<option value='' selected='selected'>Select</option>
								<option value='SSC'>S.S.C</option>
								<option value='DAKHIL'>Dakhil</option>
								<option value='Vocational'>S.S.C Vocational</option>
								<option value='Equivalent'>S.S.C Equivalent</option>
							</select> 								
						</td>
						<td> 
							<select name='sscb' class='form-control' required>
								<option value='' selected='selected'>Select</option>										
								<option value='Barisal'>Barisal</option>					
								<option value='Chittagong'>Chittagong</option>
								<option value='Comilla'>Comilla</option>
								<option value='Dhaka'>Dhaka</option>
								<option value='Dinajpur'>Dinajpur</option>
								<option value='Jessore'>Jessore</option>
								<option value='Madrasah'>Madrasah</option>
								<option value='Rajshahi'>Rajshahi</option>
								<option value='Sylhet'>Sylhet</option>										
								<option value='Technical'>Technical</option>
								<option value='Other'>Other</option>
							</select>
						</td>
						<td> 
							<input type='text' required name='sscinst'  class='form-control'/> 
						</td>
								
						<td>
							<select name='sgroup' class='form-control' required>
								<option value='' selected='selected'>Select</option>
								<option value='Science'>Science</option>
								<option value='Humanities'>Humanities</option>
								<option value='Studies'>Business Studies</option>
								<option value='Other'>Others</option>
							</select> 
						</td>
						
						<td> 
							<input type='text' required name='sscgpa'    class='form-control'/>
						</td>
						<td> 
							<input type='text' required name='sscpy'  class='form-control'/>
						</td>
								
					</tr>
					
					<tr>
						<td> 
								
							<select name='hsc' class='form-control' required>
								<option value='' selected='selected'>Select</option>														
								<option value='Alim'>Alim</option>
								<option value='Business_Management'>Business Management</option>
								<option value='Diploma'>Diploma in Engineering</option>
								<option value='HSC'>H.S.C/Genarel</option>
								<option value='Equivalent'>H.S.C Equivalent</option>
								<option value='Madrasa'>Madrasa</option>
								<option value='Other'>Other</option>
							</select>
								
						</td>
						<td> 
						
							<select name='hscb' class='form-control' required>
								<option value='' selected='selected'>Select</option>										
								<option value='Barisal'>Barisal</option>					
								<option value='Chittagong'>Chittagong</option>
								<option value='Comilla'>Comilla</option>
								<option value='Dhaka'>Dhaka</option>
								<option value='Dinajpur'>Dinajpur</option>
								<option value='Jessore'>Jessore</option>
								<option value='Madrasah'>Madrasah</option>
								<option value='Rajshahi'>Rajshahi</option>
								<option value='Sylhet'>Sylhet</option>										
								<option value='Technical'>Technical</option>
								<option value='Other'>Other</option>
							</select> 
						
						</td>
						
						<td> 
							<input type='text' required name='hscinst'  class='form-control'/> 
						</td>
						
						<td> 
							<select class='form-control' name='hgroup' required>
								<option value='' selected='selected'>Select</option>														
								<option value='Alim'>Alim</option>
								<option value='Science'>Science</option>
								<option value='Humanities'>Humanities</option>
								<option value='Studies'>Business Studies</option>
								<option value='Diploma'>Diploma in Engineering</option>
								<option value='Madrasa'>Madrasa</option>
								<option value='Other'>Other</option>					   
							</select>
						</td>
						<td> 
							<input type='text' required name='hscgpa'    class='form-control'/> 
						</td>
						<td> 
							<input type='text' required name='hscpy'  class='form-control'/> 
						</td>
								
								
					</tr>
					<tr>
						<td> 
							<input type='text' required placeholder='Honours'  name='honors'  class='form-control'/> 
						</td>
						<td> 
							<input type='text' required name='honorsb'  class='form-control'/> 
						</td>
						<td> 
							<input type='text' required name='honinst'  class='form-control'/>
						</td>
						<td> 
							<select class='form-control' name='honsub' required >
								<option value='' selected='selected'> Selected </option>
								<option value='Bangla' > Bangla </option>
								<option value='BBA' > BBA </option>
								<option value='Chymesty' > Chymestry </option>
								<option value='CSE'> CSE </option> 					   
								<option value='Civil'> Civil </option> 					   
								<option value='English'> English </option> 					   
								<option value='Economics'> Economics </option> 					   
								<option value='EEE'> EEE </option> 					   
								<option value='ICE'> ICE </option> 					   
								<option value='Pharmacy'> Pharmacy </option> 					   
								<option value='Mathametics'> Mathametics </option> 					   
								<option value='Mechanical'> Mechanical </option> 					   
								<option value='Political Science'> Political Science </option> 					   
								<option value='Journalism'> Journalism </option> 					   
								<option value='Law'> Law </option> 					   
								<option value='Islamic History'> Islamic History </option> 					   
								<option value='Statistic '> Statistic </option> 		 					   
							</select>
						</td>
						<td> 
							<input type='text' required name='honcgpa'    class='form-control'/> 
						</td>
						<td> 
							<input type='text' required name='honpy'  class='form-control'/> 
						</td>						
								
					</tr>
					
					<tr>
						<td> 
							<input type='text'  placeholder='Mastars'  name='mastars'  class='form-control'/> 
						</td>
						<td> 
							<input type='text'  name='mastarsb'  class='form-control'/> 
						</td>
						<td> 
							<input type='text'  name='mastinst'  class='form-control'/> 
						</td>
						<td> 
							<select class='form-control' name='mastsub' >
								<option value='' selected='selected'>------ </option>
								<option value='Bangla'> Bangla </option>
								<option value='BBA'> BBA </option>
								<option value='Chymesty' > Chymestry </option>
								<option value='CSE'> CSE </option> 					   
								<option value='Civil'> Civil </option> 					   
								<option value='English'> English </option> 					   
								<option value='Economics'> Economics </option> 					   
								<option value='EEE'> EEE </option> 					   
								<option value='ICE'> ICE </option> 					   
								<option value='Pharmacy'> Pharmacy </option> 					   
								<option value='Mathametics'> Mathametics </option> 					   
								<option value='Mechanical'> Mechanical </option> 					   
								<option value='Political Science'> Political Science </option> 					   
								<option value='Journalism'> Journalism </option> 					   
								<option value='Law'> Law </option> 					   
								<option value='Islamic History'> Islamic History </option> 					   
								<option value='Statistic '> Statistic </option>					   
							</select> 
						</td>
						<td> 
							<input type='text'  name='mastcgpa'    class='form-control'/> 
						</td>
						<td> 
							<input type='text'  name='mastpy'  class='form-control'/> 
						</td>						
								
					</tr>
				</tbody>
				</table>
					
					<h4> Training Information </h4>
					<table class='table ' style='font-size: 14px; font-weight: 500'>
						<tbody>
							<tr>
								<th> Training Title </th>
								<th width='100'> Duration </th>
								<th> Institute </th>
								<th> Institute Contact </th>
								<th> Institute Address </th>
								
								
							</tr>
							<tr>
								<td> <input type='text'  name='tname'  class='form-control'/> </td>
								<td> <input type='text'  name='tdur'  class='form-control'/> </td>
								<td> <input type='text'  name='tinst'  class='form-control'/> </td>
								<td> <input type='text'  name='tinstcont'  class='form-control'/> </td>
								<td> <input type='text'  name='tinstadd'  class='form-control'/> </td>								
								
							</tr>
							<tr>
								<td> <input type='text'  name='tname2'  class='form-control'/> </td>
								<td> <input type='text'  name='tdur2'  class='form-control'/> </td>
								<td> <input type='text'  name='tinst2'  class='form-control'/> </td>
								<td> <input type='text'  name='tinstcont2'  class='form-control'/> </td>
								<td> <input type='text'  name='tinstadd2'  class='form-control'/> </td>								
								
							</tr>
						</tbody>
					</table>
					<div class='form-group'>
						<button type='submit' class='btn btn-block btn-primary' name='Submit'>Submit</button>
					</div>
			</form>
					
		</div>		
	 </div>";
	}
?>
	

<?php
			$query  = "SELECT * FROM experience where exuid='".$_SESSION['user_id']."'";
			$query_data = mysqli_query($con, $query);
			$row = mysqli_fetch_array($query_data);
	
						
if ($row['exuid']!=null) 	
	{ 	        
      echo"<div id='menu2' class='tab-pane fade'>
         <div id='content'>
			<form  action='Update_Exprience' method='post' accept-charset='UTF-8'>
				
			
			<h4> Skil </h4>		 
			<div class='form-group'>
				  <label class='col-sm-2 red'>Skil  :</label>
				  <div class='col-sm-10'>
					<input type='text' value='$row[skill]' name='skill' placeholder='Exp: Java, php, Exel' class='form-control' >
				</div>
			</div><br><br>

			
				
				<h4> Experience Information </h4>
				<table class='table ' style='font-size: 14px; font-weight: 500'>
					<tbody>
						<tr>
							<th> Name of Company </th>
							<th> Designation </th>
							<th> Address </th>
							<th width='120'> Duration </th>
							<th width='135'> Mobile</th>
							
						</tr>
						
						<tr>
								<td> <input type='text' value='$row[company]'    name='company'  class='form-control'/> </td>
								<td> <input type='text' value='$row[designetion]'name='designetion' class='form-control'/> </td>
								<td> <input type='text' value='$row[address]'    name='address'  class='form-control'/> </td>
								<td> <input type='text' value='$row[duration]'   name='duration'  class='form-control'/> </td>
								<td> <input type='text' value='$row[mobile]'     name='mobile' maxlength='11'  class='form-control'/> </td>										
						</tr>
						<tr>
								<td> <input type='text' value='$row[company1]'  name='company1'  class='form-control'/> </td>
								<td> <input type='text' value='$row[designetion1]'  name='designetion1' class='form-control'/> </td>
								<td> <input type='text' value='$row[address1]'  name='address1'  class='form-control'/> </td>
								<td> <input type='text' value='$row[duration1]' name='duration1'  class='form-control'/> </td>
								<td> <input type='text' value='$row[mobile1]'  name='mobile1' maxlength='11'  class='form-control'/> </td>										
						</tr>
						<tr>
								<td> <input type='text' value='$row[company2]' name='company2'  class='form-control'/> </td>
								<td> <input type='text' value='$row[designetion2]' name='designetion2' class='form-control'/> </td>
								<td> <input type='text' value='$row[address2]' 	name='address2'  class='form-control'/> </td>
								<td> <input type='text' value='$row[duration2]' name='duration2'  class='form-control'/> </td>
								<td> <input type='text' value='$row[mobile2]' name='mobile2' maxlength='11'  class='form-control'/> </td>										
						</tr>
						
					</tbody>
				</table>
				<div class='form-group'>
					<button type='submit' class='btn btn-block btn-primary' name='Submit'>Submit</button>
				</div>
			</form>
		</div>	
	</div>";
 }
 
 else 
	 { 
	        
     echo"<div id='menu2' class='tab-pane fade'>
         <div id='content'>
			<form  action='Exprience' method='post' accept-charset='UTF-8'>
			
			<h4> Skill </h4>		 
			<div class='form-group'>
				  <label class='col-sm-2 red'>Skill  :</label>
				  <div class='col-sm-10'>
					<input type='text' required name='skill' placeholder='Exp: Java, php, Exel' class='form-control' >
				</div>
			</div><br><br>
			
			
				<h4> Experience Information </h4>
				<table class='table ' style='font-size: 14px; font-weight: 500'>
					<tbody>
						<tr>
							<th> Name of Company </th>
							<th> Designation </th>
							<th> Address </th>
							<th width='120'> Duration </th>
							<th width='135'> Mobile</th>
							
						</tr>
						
						<tr>
								<td> <input type='text'  name='company'  class='form-control'/> </td>
								<td> <input type='text'  name='designetion' class='form-control'/> </td>
								<td> <input type='text'  name='address'  class='form-control'/> </td>
								<td> <input type='text'  name='duration'  class='form-control'/> </td>
								<td> <input type='text'  name='mobile' maxlength='11'  class='form-control'/> </td>										
						</tr>
						<tr>
								<td> <input type='text'  name='company1'  class='form-control'/> </td>
								<td> <input type='text'  name='designetion1' class='form-control'/> </td>
								<td> <input type='text'  name='address1'  class='form-control'/> </td>
								<td> <input type='text'  name='duration1'  class='form-control'/> </td>
								<td> <input type='text'  name='mobile1' maxlength='11'  class='form-control'/> </td>										
						</tr>
						<tr>
								<td> <input type='text'  name='company2'  class='form-control'/> </td>
								<td> <input type='text'  name='designetion2' class='form-control'/> </td>
								<td> <input type='text'  name='address2'  class='form-control'/> </td>
								<td> <input type='text'  name='duration2'  class='form-control'/> </td>
								<td> <input type='text'  name='mobile2' maxlength='11'  class='form-control'/> </td>										
						</tr>
						
					</tbody>
				</table>
				<div class='form-group'>
					<button type='submit' class='btn btn-block btn-primary' name='Submit'>Submit</button>
				</div>
			</form>
		</div>	
	</div>";
	}
?>
   
   
 <?php
			$query  = "SELECT * FROM refarence where ruid='".$_SESSION['user_id']."'";
			$query_data = mysqli_query($con, $query);
			$row = mysqli_fetch_array($query_data);
	
						
	if ($row['ruid']!=null) 	
	{ 	        
      echo"<div id='menu3' class='tab-pane fade'>
        <div id='content'>
			<form  action='UpdateReferance.php' method='post' accept-charset='UTF-8'>
				<h4> Reference Information </h4>
				<table class='table table-bordered' style='font-size: 14px; font-weight: 500'>
					<tbody>
						<tr>
							<th> Name </th>
							<th> Designation </th>
							<th> Address </th>
							<th> Contact No</th>
							<th> Relation </th>
						</tr>
						
						<tr>
							<td> <input type='text' value='$row[name]'   name='name'  class='form-control'/> </td>
							<td> <input type='text' value='$row[designetion]' name='designetion'  class='form-control'/> </td>
							<td> <input type='text' value='$row[address]' name='address'  class='form-control'/> </td>								
							<td> <input type='text' value='$row[mobile]' name='mobile'  class='form-control'/> </td>
							<td> <input type='text' value='$row[relation]' name='relation'  class='form-control'/> </td>								
								
						</tr>	

						<tr>
							<td> <input type='text' value='$row[name1]' name='name1'  class='form-control'/> </td>
							<td> <input type='text' value='$row[designetion1]' name='designetion1'  class='form-control'/> </td>
							<td> <input type='text' value='$row[address1]' name='address1'  class='form-control'/> </td>								
							<td> <input type='text' value='$row[mobile1]' name='mobile1'  class='form-control'/> </td>
							<td> <input type='text' value='$row[relation1]' name='relation1'  class='form-control'/> </td>								
								
						</tr>						
					</tbody>
				</table>			
				<div class='form-group'>
						<button type='submit' class='btn btn-block btn-primary' name='Submit'>Submit</button>
				</div>				
			</form>
		</div>		
	 </div>";
	}
	
   else 
	{
	   echo"<div id='menu3' class='tab-pane fade'>
        <div id='content'>
			<form  action='Referance.php' method='post' accept-charset='UTF-8'>
				<h4> Reference Information </h4>
				<table class='table table-bordered' style='font-size: 14px; font-weight: 500'>
					<tbody>
						<tr>
							<th> Name </th>
							<th> Designation </th>
							<th> Address </th>
							<th> Contact No</th>
							<th> Relation </th>
						</tr>
						
						<tr>
							<td> <input type='text' required name='name'  class='form-control'/> </td>
							<td> <input type='text' required name='designetion'  class='form-control'/> </td>
							<td> <input type='text' required name='address'  class='form-control'/> </td>								
							<td> <input type='text' required name='mobile'  class='form-control'/> </td>
							<td> <input type='text' required name='relation'  class='form-control'/> </td>								
								
						</tr>	

						<tr>
							<td> <input type='text'  name='name1'  class='form-control'/> </td>
							<td> <input type='text'  name='designetion1'  class='form-control'/> </td>
							<td> <input type='text'  name='address1'  class='form-control'/> </td>								
							<td> <input type='text'  name='mobile1'  class='form-control'/> </td>
							<td> <input type='text'  name='relation1'  class='form-control'/> </td>								
								
						</tr>						
					</tbody>
				</table>			
				<div class='form-group'>
						<button type='submit' class='btn btn-block btn-primary' name='Submit'>Submit</button>
				</div>				
			</form>
		</div>		
	 </div>";
	}
?>

<?php
			$query  = "SELECT * FROM images where imuid='".$_SESSION['user_id']."'";
			$query_data = mysqli_query($con, $query);
			$row = mysqli_fetch_array($query_data);
	
						
if ($row['imuid']!=null) 	
	{ 	        
      echo"<div id='menu4' class='tab-pane fade'>          
		<div id='content'>			
			<h4> Photo </h4>
			<div class='row'>				
				<div class='col-sm-12'> 
					<img class='img-rounded' width='220' height='260' src='user_images/$row[userPic]'>
				</div>
				
			</div>
				
		</div>	
		<br><a class='btn btn-info' href='editform.php?edit_id=$row[imuid]'><span class='glyphicon glyphicon-edit'></span> Update Image</a>
		</div>"; 
	} 
	
	
	else	
	{ 	        
      echo"<div id='menu4' class='tab-pane fade'>          
		<div id='content'>			
			<h4> Photo </h4>
			<form action='addnew' method='post'  accept-charset='utf-8'>
				<div class='form-input'>
					<div class='col-sm-6'>
						<div class='red' style='font-size:17px; font-weight:bold; border:1px solid #ed0101; padding:5px; margin-bottom:15px'>
							N.B:
							<br>
							<ol>
								<li> Use (Width 220 x Height 260) Pixels Image. </li>
								<li> Image size should be less than 100KB. </li>
								<li> Use 'jpg' formate image only.</li>
							</ol>
						</div>
						<div>	
							<a class='btn btn-default' href='addnew.php?add_pic=$_SESSION[user_id]'> <span class='glyphicon glyphicon-plus'></span> &nbsp; add new </a>
						</div>						
					</div>
					<div class='col-sm-6'> </div>
				</div>
			</form>
		</div>
		<div class='clearfix'></div>
		<div id='uploaded_images' class='uploaded-images'>
			<div id='error_div' class='red'>
			</div>
			<div id='success_div'>			
			</div>		
		</div>
		
							
	</div>"; 
	} 
        ?>
        
   </div>
      <hr>
     
</div>
    
    
	
	
    <script>
		$(document).ready(function(){
			$('.nav-tabs a').click(function(){
			$(this).tab('show');
		});
		$('.nav-tabs a').on('shown.bs.tab', function(event)
		{
		var x = $(event.target).text();         // active tab
		var y = $(event.relatedTarget).text();  // previous tab
		$('.act span').text(x);
		$('.prev span').text(y);
		});
		});
    </script>
	
	
    <script src="js/script.js"></script>
  </body>
  
</body>
</html>