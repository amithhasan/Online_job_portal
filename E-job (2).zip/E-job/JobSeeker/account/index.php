<?php require_once("config.php"); ?>
<?php require_once("../session.php"); ?>
<?php require_once("../functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header("Location: ../../Login");
	
	
	}	
?>


<!DOCTYPE html>
<html lang="en">
<head>
	
	<title>Welcome -
            <?php echo $Name; ?>
    </title>
	<link href="css/bootstrap.css" 			rel="stylesheet">			</link>
	<link href="css/style.css" 				rel="stylesheet">		    </link>
	<link id="themeLink" href="css/themes/blue.css" rel="stylesheet"></link>
	<link type="text/css" href="css/tabbed.css" rel="stylesheet" </link>
	<link media="screen" href="css/blue.css" type="text/css" rel="stylesheet"> </link>
	
	
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	
	
</head>
<body>
		
<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<ul class="zetta-menu">
				<li><a href="../index"> Main Home</a></li>
				<li><a href=""> Home</a></li>
				<li><a href="profile?uid=<?php echo $pid;?>"> Update Profile </a></li>
				<li><a href=""> Download CV</a></li>
				<li class="zm-right-item zm-right-align">
					<a>
                                <i class="fa fa-user"></i>&nbsp;

								<?php                                         
                                
								 if($pid!=NULL and $pass!=NULL)
                                {
                                   echo $Name;
                                }
                                else
                                    echo 'Not in';                                                               

                                ?> &nbsp;<span class='caret'></span>

                    </a>
					
					
					<ul><li><a href="../logout">Logout</a></li></ul>
				</li>
				<li><a href=""> Contact </a></li>
			</ul>
		</div>
	</div>
</div>
			
<div class="container">
			
	<div class="row">
	   <div class="col-sm-12">
		<h3 id="form_head">Applicant Profile Edit</h3>
		<hr>
		<section id="tabbed">
			<input id="t-1" type="radio" checked="checked" name="tabbed-tabs">
			<label class="tabs" for="t-1">Basic Info</label>
			
			<input id="t-2" type="radio" name="tabbed-tabs">
			<label class="tabs" for="t-2">Education & Training</label>
			
			<input id="t-4" type="radio" name="tabbed-tabs">
			<label class="tabs" for="t-4">Experience</label>
			<input id="t-5" type="radio" name="tabbed-tabs">
			<label class="tabs" for="t-5">Reference</label>
			<input id="t-6" type="radio" name="tabbed-tabs">
			<label class="tabs" for="t-6">Photo</label>
			
			<div class="wrapper">
				<div class="tab-1">
					<div class="row">
						<div class="col-sm-12">
							<div id="content">
							
			<?php
				$query  = "SELECT * FROM basic_info where uid='".$_SESSION['user_id']."' ";
				$query_data = mysqli_query($con, $query);
					while($row = mysqli_fetch_array($query_data))
					{	
			?>	
								
									<h4> Basic Information </h4>
									<div class="table-responsive">
										<table class="table table-bordered">
											<tbody>
												<tr>
													<th width="200"> Name </th>
													<td><?php echo $row['name'];?></td>
												</tr>
												<tr>
													<th> Father's Name </th>
													<td><?php echo $row['fname'];?>  </td>
												</tr>
												<tr>
													<th> Father's Occupation </th>
													<td><?php echo $row['foccup'];?>  </td>
												</tr>
												
												
												<tr>
													<th> Mother's Name </th>
													<td><?php echo $row['mname'];?>  </td>
												</tr>
												<tr>
													<th> Mother's Occupation </th>
													<td> <?php echo $row['moccup'];?> </td>
												</tr>
												
												<tr>
													<th> Email </th>
													<td><?php echo $row['email'];?>  </td>
												</tr>
												<tr>
													<th> Mobile </th>
													<td><?php echo $row['mobile'];?>  </td>
												</tr>
												<tr>
													<th> Home Phone </th>
													<td><?php echo $row['hmobile'];?>  </td>
												</tr>
												<tr>
													<th> Date of Birth </th>
													<td><?php echo $row['bdate'];?>  </td>
												</tr>
												
												<tr>
													<th> Blood Group </th>
													<td><?php echo $row['blood'];?>  </td>
												</tr>
												<tr>
													<th> Religion </th>
													<td><?php echo $row['religion'];?>  </td>
												</tr>
												<tr>
													<th> Nationality </th>
													<td><?php echo $row['nationality'];?>  </td>
												</tr>
												
												<tr>
													<th> National ID </th>
													<td><?php echo $row['nid'];?>  </td>
												</tr>
												
								<?php if($row['nino']!="") 
									{
										echo "<tr>
													<th> NID Number </th>
													<td> ".$row['nino']."</td>
												</tr>";
									}						
								  ?>			
												
												
												<tr>
													<th> Marital Status </th>
													<td><?php echo $row['mstatus'];?>  </td>
												</tr>
												
								<?php if($row['spouse']!="") 
									{
										echo "<tr>
													<th> Spouse Name </th>
													<td> ".$row['spouse']."</td>
												</tr>";
										}									
								  ?>		
												
												<tr>
													<th> Gender </th>
													<td><?php echo $row['gender'];?>  </td>
												</tr>
												<tr>
													<th> Height </th>
													<td><?php echo $row['height'];?>  </td>
												</tr>
												<tr>
													<th> Weight </th>
													<td><?php echo $row['weight'];?>  </td>
												</tr>
											</tbody>
										</table>
									</div>
									
									
									<h4> Address </h4>
									<div>
										<label> Present Address </label>
										Village: <?php echo $row['vill'];?>, P.O: <?php echo $row['po'];?>, Thana: <?php echo $row['thana'];?>, District: <?php echo $row['dist'];?>
									</div>
									<div>
										<label> Present Address </label>
										Village: <?php echo $row['pvill'];?>, P.O: <?php echo $row['ppo'];?>, Thana: <?php echo $row['pthana'];?>, District: <?php echo $row['pdist'];?>
									</div>
									<br>
									<a class="nyroModal button-submit" href="profile.php?uid=<?php echo $pid;?>">Update</a>
									
						
						
						<?php 
						}
						?>
						
							</div>
						</div>
					</div>
				</div>
				
				<div class="tab-2">
					<div class="row">
						<div class="col-sm-12">
							<div id="content">
								<h4> Educational Information </h4>
								<table class="table table-bordered" style="font-size: 14px; font-weight: 500">
									<tbody>
									
					<?php
						$query  = "SELECT * FROM education where euid='".$_SESSION['user_id']."'";
						$query_data = mysqli_query($con, $query);
							while($row = mysqli_fetch_array($query_data))
							{	
					?>				
									
										<tr>
											<th> Degree </th>
											<th> Board </th>
											<th> Institute </th>
											<th> Group </th>
											<th> Result </th>
											<th> Passing Year </th>
											
										</tr>
										<tr>
											<td><?php echo $row['ssc'];?> </td>
											<td><?php echo $row['sscb'];?>  </td>
											<td><?php echo $row['sscinst'];?>  </td>
											<td><?php echo $row['sgroup'];?>  </td>
											<td><?php echo $row['sscgpa'];?>  </td>
											<td><?php echo $row['sscpy'];?> </td>
											
										</tr>
										<tr>
											<td><?php echo $row['hsc'];?> </td>
											<td><?php echo $row['hscb'];?>  </td>
											<td><?php echo $row['hscinst'];?>  </td>
											<td><?php echo $row['hgroup'];?>  </td>
											<td><?php echo $row['hscgpa'];?> </td>
											<td><?php echo $row['hscpy'];?>  </td>
											
										</tr>
										<tr>
											<td><?php echo $row['honors'];?></td>
											<td><?php echo $row['honorsb'];?>  </td>
											<td><?php echo $row['honinst'];?>  </td>
											<td><?php echo $row['honsub'];?>  </td>
											<td><?php echo $row['honcgpa'];?> </td>
											<td><?php echo $row['honpy'];?>  </td>
											
										</tr>
										
										<tr>
											<td><?php echo $row['mastars'];?> </td>
											<td><?php echo $row['mastarsb'];?>  </td>
											<td><?php echo $row['mastinst'];?>  </td>
											<td><?php echo $row['mastsub'];?>  </td>
											<td><?php echo $row['mastcgpa'];?> </td>
											<td><?php echo $row['mastpy'];?>  </td>
											
										</tr>
									</tbody>
								</table>
								
								<h4> Training Information </h4>
								<table class="table table-bordered" style="font-size: 14px; font-weight: 500">
									<tbody>
										<tr>
											<th> Training Title </th>
											<th> Duration </th>
											<th> Institute </th>
											<th> Institute Contact </th>
											<th> Institute Address </th>

											
										</tr>
										<tr>
											<td><?php echo $row['tname'];?>  </td>
											<td><?php echo $row['tdur'];?>  </td>
											<td><?php echo $row['tinst'];?>  </td>
											<td><?php echo $row['tinstcont'];?>  </td>
											<td><?php echo $row['tinstadd'];?>  </td>											
										</tr>
										<tr>
											<td><?php echo $row['tname2'];?>  </td>
											<td><?php echo $row['tdur2'];?>  </td>
											<td><?php echo $row['tinst2'];?>  </td>
											<td><?php echo $row['tinstcont2'];?>  </td>
											<td><?php echo $row['tinstadd2'];?>  </td>											
										</tr>
						<?php } ?>					
									</tbody>
								</table>
								<a class="nyroModal button-submit" href="profile.php?uid=<?php echo $pid;?>">Update</a>
							</div>
						</div>
					</div>
				</div>
	
				
				
		<div class="tab-4">
			<div class="row">
				<div class="col-sm-12">
					<div id="content">
					<h4> Experience Information </h4>
					<table class="table table-bordered" style="font-size: 14px; font-weight: 500">
						<tbody>
								
					<?php
						$query  = "SELECT * FROM experience where exuid='".$_SESSION['user_id']."'";
						$query_data = mysqli_query($con, $query);
							while($row = mysqli_fetch_array($query_data))
							{	
					?>		
									<tr>
										<th> Name of Company </th>
										<th> Designation </th>
										<th> Address </th>
										<th> Duration </th>
										<th> Mobile</th>
										
									</tr>
									
							<tr>
										<td><?php echo $row['company'];?>    </td>
										<td><?php echo $row['designetion'];?>  </td>
										<td><?php echo $row['address'];?>  </td>
										<td><?php echo $row['duration'];?>  </td>
										<td><?php echo $row['mobile'];?>  </td>											
							</tr>
							<tr>
										<td><?php echo $row['company1'];?>  </td>
										<td><?php echo $row['designetion1'];?>  </td>
										<td><?php echo $row['address1'];?>  </td>
										<td><?php echo $row['duration1'];?>  </td>
										<td><?php echo $row['mobile1'];?>  </td>											
							</tr>
							<tr>
										<td><?php echo $row['company2'];?>  </td>
										<td><?php echo $row['designetion2'];?>  </td>
										<td><?php echo $row['address2'];?>  </td>
										<td><?php echo $row['duration2'];?>  </td>
										<td><?php echo $row['mobile2'];?>  </td>											
							</tr>									
					</table>
					<h4> Skill Information </h4>
					<table class="table table-bordered" style="font-size: 14px; font-weight: 500">
							<tbody>
								<tr>
											<th> Skill </th>																						
								</tr>
										
								<tr>
											<td><?php echo $row['skill'];?>  </td>																				
								</tr>
			<?php } ?>					
							</tbody>
					</table>
					
					
							<a class="nyroModal button-submit" href="profile.php?uid=<?php echo $pid;?>">Update</a>
					</div>
				</div>
			</div>
		</div>
							
				
				<div class="tab-5">
					<div class="row">
						<div id="content">
							<h4> Reference Information </h4>
						<table class="table table-bordered" style="font-size: 14px; font-weight: 500">
							<tbody>
							
					<?php
						$query  = "SELECT * FROM refarence where ruid='".$_SESSION['user_id']."'";
						$query_data = mysqli_query($con, $query);
							while($row = mysqli_fetch_array($query_data))
							{	
					?>	
							
							
							<tr>
										<th> Name </th>
										<th> Designation </th>
										<th> Address </th>
										<th> Contact No</th>
										<th> Relation </th>
										
							</tr>
									
							<tr>
										<td><?php echo $row['name'];?>    </td>
										<td><?php echo $row['designetion'];?>  </td>
										<td><?php echo $row['address'];?>  </td>
										<td><?php echo $row['mobile'];?>  </td>
										<td><?php echo $row['relation'];?>  </td>											
							</tr>
							<tr>
										<td><?php echo $row['name1'];?>    </td>
										<td><?php echo $row['designetion1'];?>  </td>
										<td><?php echo $row['address1'];?>  </td>
										<td><?php echo $row['mobile1'];?>  </td>
										<td><?php echo $row['relation1'];?>  </td>											
							</tr>
									
									
							<?php } ?>		
									
								</tbody>
						</table>
							<a class="nyroModal button-submit" href="profile.php?uid=<?php echo $pid;?>">Update</a>
						</div>
					</div>
				</div>
				
	<div class="tab-6">
		<div class="row">
			<div id="content">							
				<h4> Photo </h4>							
				<div class="form-input">
					<div class="col-sm-6">
						<div class="red" style="font-size:17px; font-weight:bold; padding:5px; margin-bottom:15px">
							
	<?php 

		$sql = "SELECT * FROM `images` where imuid='".$_SESSION['user_id']."' ";
			if ($result=mysqli_query($con,$sql))
			{
				while($row=mysqli_fetch_array($result))
			{
	echo "<img class='img-rounded' width='220' height='260' src='user_images/$row[userPic]'> ";
			}					 					
			}
			mysqli_close($con);
				
	?>	
							
						</div>		
<a class="nyroModal button-submit" href="profile.php?uid=<?php echo $pid;?>">Update</a>						
					</div>									
				</div>							
			</div>
		</div>
	</div>
				
			</div>
		</section>
	</div>
   </div>
</div>
															
</body>
</html>