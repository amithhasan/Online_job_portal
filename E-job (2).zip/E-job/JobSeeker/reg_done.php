<?php
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "e-job"; //Database name

	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$name =      $_POST['name'];
	$username  = $_POST['username'];
	$gender  =   $_POST['gender'];
	$email  =    $_POST['email'];	
	$password = hash('sha256', $_POST['password']);   
	
	// $password  = md5($_POST['password']); here password encript md5 http://md5decrypt.net/en/Sha256/ decript
		
	
	$sql= "INSERT INTO `users`(`user_id`, `name`, `username`, `gender`, `email`, `password`) 
	VALUES ('', '$name', '$username', '$gender', '$email', '$password')";
	

	if (mysqli_query($conn, $sql)) 
	{
		echo "<script>alert('Successfully registered!'); window.location='../Login'</script>";
	} 
	else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?> 

