<?php require_once('header.php'); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<br>
<div class="container">
        <div class="row">          
			<div class="col-sm-12">                
                    <form class="m" id="form1" name="form1" method="post" action="index.php">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <h4 for="to">Min Salary :</h4>
                                    <input name="to" type="txt" id="to" class="form-control" value="" /> </div>
                            </div>
                            <!--Here Minimum price-->
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <h4 for="from">Max Salary :</h4>
                                    <input name="from" type="txt" id="from" class="form-control" value="" /> </div>
                            </div>
                            <!--Here Maximum price-->
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <h4 for="to">Experience :</h4>
                                    <select name="string" class="form-control">
                                        <option value="" selected="selected">Any Type</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </select>
								</div>
                            </div>
                        </div>
                        <!--Here Selet Division-->
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="sel1">Location :</label>
                                    <select name="title" class="form-control" id="sel1">
                                        <option value="" selected="selected">Any Where</option>
                                        <option value="1">Dhaka</option>
                                        <option value="2">Faridpur</option>
                                        <option value="3">Gazipur</option>
                                        <option value="4">Gopalganj</option>
                                        <option value="5">Jamalpur</option>
                                        <option value="6">Kishoreganj</option>
                                        <option value="7">Madaripur</option>
                                        <option value="8">Manikganj</option>
                                        <option value="9">Munshiganj</option>
                                        <option value="10">Mymensingh </option>
                                        <option value="11">Narayanganj </option>
                                        <option value="12">Narsingdi </option>
                                        <option value="13">Netrakona </option>
                                        <option value="14">Rajbari </option>
                                        <option value="15">Shariatpur </option>
                                        <option value="16">Sherpur </option>
                                        <option value="17">Tangail </option>
                                        <option value="18">Barguna </option>
                                        <option value="19">Barisal </option>
                                        <option value="20">Bhola </option>
                                        <option value="21">Jhalokati </option>
                                        <option value="22">Patuakhali </option>
                                        <option value="23">Pirojpur </option>
                                        <option value="24">Bandarban </option>
                                        <option value="25">Brahmanbaria </option>
                                        <option value="26">Chandpur </option>
                                        <option value="27">Chittagong </option>
                                        <option value="28">Comilla </option>
                                        <option value="29">Cox&#039;s Bazar </option>
                                        <option value="30">Feni </option>
                                        <option value="31">Khagrachhari </option>
                                        <option value="32">Lakshmipur </option>
                                        <option value="33">Noakhali </option>
                                        <option value="34">Rangamati </option>
                                        <option value="35">Bagerhat </option>
                                        <option value="36">Chuadanga </option>
                                        <option value="37">Jessore </option>
                                        <option value="38">Jhenaidah </option>
                                        <option value="39">Khulna </option>
                                        <option value="40">Kushtia </option>
                                        <option value="41">Magura </option>
                                        <option value="42">Meherpur </option>
                                        <option value="43">Narail </option>
                                        <option value="44">Satkhira </option>
                                        <option value="45">Bogra </option>
                                        <option value="46">Joypurhat </option>
                                        <option value="47">Naogaon </option>
                                        <option value="48">Natore </option>
                                        <option value="49">Nawabganj </option>
                                        <option value="50">Pabna </option>
                                        <option value="51">Rajshahi </option>
                                        <option value="52">Sirajganj </option>
                                        <option value="53">Dinajpur </option>
                                        <option value="54">Gaibandha </option>
                                        <option value="55">Kurigram </option>
                                        <option value="56">Lalmonirhat </option>
                                        <option value="57">Nilphamari </option>
                                        <option value="58">Panchagarh </option>
                                        <option value="59">Rangpur </option>
                                        <option value="60">Thakurgaon </option>
                                        <option value="61">Habiganj </option>
                                        <option value="62">Moulvibazar </option>
                                        <option value="63">Sunamganj </option>
                                        <option value="64">Sylhet </option>
                                    </select>
                                </div>
                            </div>
                            <!--  Here select Job Type  -->
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="sel1">Job Type :</label>
                                    <select name="string" class="form-control">
                                        <option value="" selected="selected">Any Type</option>
                                        <option value="1">Full Time</option>
                                        <option value="2">Part Time</option>
                                        <option value="3">Contractual</option>
                                    </select>
                                </div>
                            </div>
                            <!--  Here select Expert  -->
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="sel1">Expert :</label>
                                    <select name="string" class="form-control">
                                        <option value="" selected="selected">Any Language </option>
                                        <option value="1">C</option>
                                        <option value="2">C++</option>
                                        <option value="3">Java</option>
                                        <option value="4">PHP</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <!--   Here submit  -->
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-4"></div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <button type="submit" id="button" value="Filter" class="btn btn-block btn-primary" name="btn-login">Search</button>
                                    </div>
                                </div>
                                <div class="col-sm-4"></div>
                            </div>
                        </div>
                    </form>
                </div>
        </div>
    </div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php require_once('Footer.php'); ?>	