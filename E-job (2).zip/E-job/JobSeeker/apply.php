<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php require_once('header.php'); ?>
<?php 
    if(logged_in())
    {
	$Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else
	{
		$user=NULL;
		$pass=NULL;
		header('Location: ../Login');		
	}	

    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "e-job"; 


	$conn = mysqli_connect($servername, $username, $password, $dbname);

	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$job_id    	=    $_GET['j_id'];
	$c_id    	=    $_GET['c_id'];
	

	
	
	$sql= "INSERT INTO `apply`(`id`, `job_id`, `u_id` ,`c_id`) VALUES  ('', '$job_id',	'$pid', '$c_id')";
	
	
	
	
	if (mysqli_query($conn, $sql)) 
	{
		echo "<script>alert('Successfully Added!'); window.location='profile'</script>";
	} 
	else 
	{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?> 