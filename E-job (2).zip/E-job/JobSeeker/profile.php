<?php require_once("header.php"); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
            <?php 
    if(logged_in())
    {
	$Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('location:../index');
	
	}	
?>
<?php
	$host = "localhost";
	$user  = "root";
	$password =  "";
	$database1 = "e-job";

	$conn = mysqli_connect($host, $user, $password, $database1);


 $q ="Select * from users 
	inner join refarence on users.user_id = refarence.ruid 
	inner join images on refarence.ruid = images.imuid 
	inner join experience on images.imuid = experience.exuid 
	inner join education on experience.exuid = education.euid 
	inner join basic_info on education.euid = basic_info.uid  WHERE user_id = '".$_SESSION['user_id']."' ";

    
	$result = mysqli_query($conn, $q);
    $row = mysqli_fetch_array($result);


?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <title> <?php echo $row['name']; ?> </title>
</head>

<body>
<div class="container-fluid" id="content">
        <aside class="col-sm-3" role="complementary">
            <div class="well" id="sidebar">
			<h3><center><strong><?php echo $row['name']; ?> </strong>	</center></h3>
                <div class="thumbnail">
							<?php if($row['userPic']!="") 
					{
						echo "<img class='img-circle' src = 'account/user_images/".$row['userPic']."' class='img-circle' >";
					}
					else echo" <img src='user_fallback.png'>";
				  ?> 
				</div> 
			</div>
		</aside>
    <!------------------------------------------------------------------------------- -->
    <section class="col-sm-9">
        <div id="searchcontent">
			<div id="header">
                <div class="tab-content">
				<h3> <b>Basic Info</b></h3>
                   <?php if($row['name']!="") 
					{
						echo "<table class='table table-striped'>
                                <tr>
                                    <td class='tbold'>Full Name:</td>
                                    <td>
                                         ".$row['name']."
                                    </td>
                                </tr>
                                <tr>
                                    <td class='tbold'>Email:</td>
                                    <td>
                                        ".$row['email']."
                                    </td>
                                </tr>
								<tr>
									<td class='tbold'> Gender </td>
									<td> ".$row['gender']."  </td>
								</tr>
								<tr>
                                    <td class='tbold'>Date Of Birth:</td>
                                    <td>
                                         ".$row['bdate']."
                                    </td>
                                </tr>								
                                <tr>
                                    <td class='tbold'>Phone:</td>
                                    <td>
                                         ".$row['mobile']."
                                    </td>
                                </tr>
								<tr>
                                    <td class='tbold'>Blood:</td>
                                    <td>
                                         ".$row['blood']."
                                    </td>
                                </tr>
								<tr>
                                    <td class='tbold'>Religion:</td>
                                    <td>
                                         ".$row['religion']."
                                    </td>
                                </tr>
								<tr>
									<td> Nationality </td>
									<td> ".$row['nationality']."  </td>
								</tr>
                                <tr>
                                    <td class='tbold'>Location:</td>
                                    <td>
                                         ".$row['pvill'].", ".$row['ppo'].", ".$row['pthana'].", ".$row['pdist']."
                                    </td>
                                </tr>                               								                             								
                            </table>";
					} 
					else
						echo "<a  href='account/profile.php?uid=$pid'>Edit</a>";
					?>
                           
						   
				<h3> <b>Education</b></h3>
                    
				<table class='table table-striped'>
                    <?php if($row['honors']!="") 
					{       echo "<tr>
                                    <td class='tbold'>UG Qualification:</td>
                                    <td>
                                         ".$row['honors']."
                                    </td>
                                </tr>";
					} else
						echo "<a  href='account/profile.php?uid=$pid'>Edit</a>";
					?> 			
								
                        <?php if($row['mastars']!="") 
							{
								echo "<tr>
									<td class='tbold'>PG Qualification: </td>								
									<td>												 
										".$row['mastars']."
									</td>
								</tr>";									  
                            
							} ?>
				</table>
							
                   <h3><b>Skills</b></h3>
                    <?php if($row['skill']!="") 
					{
						echo "<table class='table table-striped'>

                                <tr>
                                    <td class='tbold'>Skills:</td>
                                    <td>
                                         ".$row['skill']."
                                    </td>
                                </tr>							
                            </table>";
					} else 
						echo "<a  href='account/profile.php?uid=$pid'>Edit</a>";
					?>
					
					
                   <h3><b>Experience Any Job</b></h3>
                   <?php if($row['company']!="") 
					{
						echo "<table class='table table-striped'>
							
								<tr>
                                    <td class='tbold'>Company:</td>
                                    <td>
                                         ".$row['company']." 
                                    </td>
                                </tr>
                                <tr>
                                    <td class='tbold'>Designetion:</td>
                                    <td>
                                         ".$row['designetion']."
                                    </td>
                                </tr>
								
                                 <tr>
                                    <td class='tbold'>Experience (Years):</td>
                                    <td>
                                         ".$row['duration']."
                                    </td>
                                </tr>                               							
                            </table>";
					} else 
						echo "<a  href='account/profile.php?uid=$pid'>Edit</a>";
					?>
                                    <?php if($row['tname']!="") 
						{
													
							echo"<h3> <b>Trainnig</b></h3>
                            <table class='table table-striped'>
							
                                <tr>
                                    <td class='tbold'>Trainnig Name:</td>
                                    <td>
                                          ".$row['tname']." 
                                    </td>
                                </tr>
								<tr>
                                    <td class='tbold'>Trainnig Duration:</td>
                                    <td>
                                         ".$row['tdur']." 
                                    </td>
                                </tr>
								<tr>
											
									<td class='tbold'>Trainnig Institute:</td>
									<td> ".$row['tinst']."  </td>
											
																						
								</tr>
						                              							
                            </table>";
						}
									
					?> 
				</div>
			</div>
		</div>
    </section>    
</div>
</body>

<link href="../css/main.css" rel="stylesheet">
<script src="../js/jquery-1.12.0.min.js"></script>
<script src="../js/bootstrap.min.js"></script>

</html>
<?php require_once("footer.php"); ?>