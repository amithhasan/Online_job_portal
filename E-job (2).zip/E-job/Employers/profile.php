<?php require_once('header.php'); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['employes_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('location:../index');	
	}	
?>
<div class="container">				
	<div class="row">
		<div class="col-sm-12">
							
			<?php
				$query  = "SELECT * FROM employes where employes_id='".$_SESSION['employes_id']."' ";
				$query_data = mysqli_query($conn, $query);
					while($row = mysqli_fetch_array($query_data))
					{	
			?>	
								
					<h3 style="padding:15px;background-color:#C44D2D;color:white;height:50px;"><b> Basic Information</b> </h3>
									<div class="table-responsive">
										<table class="table table-bordered">
											<tbody>
												<tr>
													<th width="200"> Name </th>
													<td><?php echo $row['name'];?></td>
												</tr>
												<tr>
													<th> User Name </th>
													<td><?php echo $row['username'];?>  </td>
												</tr>
												<tr>
													<th> Company Name </th>
													<td><?php echo $row['company'];?>  </td>
												</tr>
												
												
												<tr>
													<th> Email </th>
													<td><?php echo $row['email'];?>  </td>
												</tr>
												<tr>
													<th> Mobile </th>
													<td><?php echo $row['mobile'];?>  </td>
												</tr>
												<tr>
													<th> Industry Type </th>
													<td> <?php echo $row['indtype'];?> </td>
												</tr>
												
												<tr>
													<th> Division </th>
													<td><?php echo $row['distict'];?>  </td>
												</tr>
												<tr>
													<th> Company Details </th>
													<td><?php echo $row['details'];?>  </td>
												</tr>
												<tr>
													<th> Website </th>
													<td><a href="<?php echo $row['url'];?>"><?php echo $row['url'];?></a></td>
												</tr>
												
											</tbody>
										</table>
									</div><br/>
						<a style="padding: 15px;background-color:#C44D2D; height:50px;color:white;" class="button-submit" href="update-profile.php?uid=<?php echo $pid;?>">Update</a>
									
						
						
						<?php 
						}
						?>
						
			</div>
		</div>
</div><br/>
<?php require_once('Footer.php'); ?>