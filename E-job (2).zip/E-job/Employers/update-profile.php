<?php require_once('header.php'); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['employes_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('location:../index');	
	}	
?>


<div class="container">				
	<div class="row">
		<div class="col-sm-12">
<?php
				$query  = "SELECT * FROM employes where employes_id='".$_SESSION['employes_id']."' ";
				$query_data = mysql_query($query);
					while($row = mysql_fetch_array($query_data))
					{	
?>
			<h3 style="padding:15px;background-color:#C44D2D;color:white;height:50px;"><b> Basic Information</b> </h3>
		<form   class='form-horizontal' action='update.php' method='post' role='form' >
			<div class='form-group'>
			  <label class='col-sm-4'>Name  </label>
			  <div class='col-sm-8'>
				<input type='text' name='name' value='<?php echo $row['name'];?>'  class='form-control' >
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>User Name  </label>
			  <div class='col-sm-8'>
				<input type='text' name='username'value='<?php echo $row['username'];?>' class='form-control' disabled/>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Company Name  </label>
			  <div class='col-sm-8'>
				<input type='text' name='company' class='form-control' value='<?php echo $row['company'];?>' disabled/>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Email  </label>
			  <div class='col-sm-8'>
				<input type='email' name='email' class='form-control' value='<?php echo $row['email'];?>' disabled/>
			  </div>
			</div>
			<div class='form-group'>
			  <label class='col-sm-4'>Mobile  </label>
			  <div class='col-sm-8'>
				<input type='text' name='mobile' class='form-control' value='<?php echo $row['mobile'];?>' />
			  </div>
			</div>
			
			<div class="form-group">  
				 <label class='col-sm-4'>Industry Type  </label>
                <div class="col-sm-8">
                <select name="indtype" id="indtype" class="form-control"  required>
                    <option selected="selected" value="<?php echo $row['indtype'];?>"><?php echo $row['indtype'];?></option>
                    <option value="Accessories/Apparel/Fashion Design">Accessories/Apparel/Fashion Design</option>
                    <option value="Accounting/Consulting/Taxation">Accounting/Consulting/Taxation</option>
                    <option value="Advertising/Event Management/PR">Advertising/Event Management/PR</option>
                    <option value="Agriculture/Dairy Technology">Agriculture/Dairy Technology</option>
                    <option value="Airlines/Hotel/Hospitality/Travel/Tourism/Restaurants">Airlines/Hotel/Hospitality/Travel/Tourism/Restaurants</option>
                    <option value="Animation / Gaming">Animation / Gaming</option>
                    <option value="Architectural Services/ Interior Designing">Architectural Services/ Interior Designing</option>
                    <option value="Auto Ancillary/Automobiles/Components">Auto Ancillary/Automobiles/Components</option>
                    <option value="Banking/Financial Services/Stockbroking/Securities">Banking/Financial Services/Stockbroking/Securities</option>
                    <option value="Banking/FinancialServices/Broking">Banking/FinancialServices/Broking</option>
                    <option value="Biotechnology/Pharmaceutical/Clinical Research">Biotechnology/Pharmaceutical/Clinical Research</option>
                    <option value="Brewery/Distillery">Brewery/Distillery</option>
                    <option value="Cement/Construction/Engineering/Metals/Steel/Iron">Cement/Construction/Engineering/Metals/Steel/Iron</option>
                    <option value="Ceramics/Sanitaryware">Ceramics/Sanitaryware</option>
                    <option value="Chemicals/Petro Chemicals/Plastics">Chemicals/Petro Chemicals/Plastics</option>
                    <option value="Computer Hardware/Networking">Computer Hardware/Networking</option>
                    <option value="Consumer FMCG/Foods/Beverages">Consumer FMCG/Foods/Beverages</option>
                    <option value="Consumer Goods - Durables">Consumer Goods - Durables</option>
                    <option value="Courier/Freight/Transportation/Warehousing">Courier/Freight/Transportation/Warehousing</option>
                    <option value="CRM/ IT Enabled Services/BPO">CRM/ IT Enabled Services/BPO</option>
                    <option value="Education/Training/Teaching">Education/Training/Teaching</option>
                    <option value="Electricals/Switchgears">Electricals/Switchgears</option>
                    <option value="Employment Firms/Recruitment Services Firms">Employment Firms/Recruitment Services Firms</option>
                    <option value="Entertainment/Media/Publishing/Dotcom">Entertainment/Media/Publishing/Dotcom</option>
                    <option value="Export Houses/Textiles/Merchandise">Export Houses/Textiles/Merchandise</option>
                    <option value="FacilityManagement">FacilityManagement</option>
                    <option value="Fertilizers/Pesticides">Fertilizers/Pesticides</option>
                    <option value="FoodProcessing">FoodProcessing</option>
                    <option value="Gems and Jewellery">Gems and Jewellery</option>
                    <option value="Glass">Glass</option>
                    <option value="Government/Defence">Government/Defence</option>
                    <option value="Healthcare/Medicine">Healthcare/Medicine</option>
                    <option value="HeatVentilation/AirConditioning">HeatVentilation/AirConditioning</option>
                    <option value="Insurance">Insurance</option>
                    <option value="KPO/Research/Analytics">KPO/Research/Analytics</option>
                    <option value="Law/Legal Firms">Law/Legal Firms</option>
                    <option value="Machinery/Equipment Manufacturing/Industrial Products">Machinery/Equipment Manufacturing/Industrial Products</option>
                    <option value=">Mining">Mining</option>
                    <option value="NGO/Social Services">NGO/Social Services</option>
                    <option value="Office Automation">Office Automation</option>
                    <option value="Others/Engg. Services/Service Providers">Others/Engg. Services/Service Providers</option>
                    <option value="Petroleum/Oil and Gas/Projects/Infrastructure/Power/Non-conventional Energy">Petroleum/Oil and Gas/Projects/Infrastructure/Power/Non-conventional Energy</option>
                    <option value="Printing/Packaging">Printing/Packaging</option>
                    <option value="Publishing">Publishing</option>
                    <option value="Real Estate">Real Estate</option>
                    <option value="Retailing">Retailing</option>
                    <option value="Security/Law Enforcement">Security/Law Enforcement</option>
                    <option value="Shipping/Marine">Shipping/Marine</option>
                    <option value="Software Services">Software Services</option>
                    <option value="Steel">Steel</option>
                    <option value="Strategy/ManagementConsultingFirms">Strategy/ManagementConsultingFirms</option>
                    <option value="Telecom Equipment/Electronics/Electronic Devices/RF/Mobile Network/Semi-conductor">Telecom Equipment/Electronics/Electronic Devices/RF/Mobile Network/Semi-conductor</option>
                    <option value="Telecom/ISP">Telecom/ISP</option>
                    <option value="Tyres">Tyres</option>
                    <option value="WaterTreatment/WasteManagement">WaterTreatment/WasteManagement</option>
                    <option value="Wellness/Fitness/Sports">Wellness/Fitness/Sports</option>
                </select>
                </div>
            </div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Division  </label>
			  <div class='col-sm-8'>
				<input type='text' name='distict' class='form-control' value='<?php echo $row['distict'];?>' disabled/>
			  </div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Company Details  </label>
				<div class="col-sm-8">
					<textarea  name="details"  class="form-control" rows="5" required ><?php echo $row['details'];?></textarea>
				</div>
			</div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Website  </label>
			  <div class='col-sm-8'>
				<input type='text' name='url' class='form-control' value='<?php echo $row['url'];?>'/>
			  </div>
			</div>
			
			<div class="form-group">
				<button type="submit" class="btn btn-block btn-primary" name="Submit">Send</button>
			</div>
	
		</form>
	
	
	<?php 
		}
	?>
		</div>
	</div>
</div>
<?php require_once('Footer.php'); ?>