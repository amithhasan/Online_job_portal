<?php require_once('header.php'); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
		$Name=$_SESSION['name'];
		$user=$_SESSION['username'];   //_SESSION is a PHP keyword
		$pass=$_SESSION['password'];   
		$pid= $_SESSION['employes_id'];
    
    }
	else{
		$user=NULL;
		$pass=NULL;
		header('location:../index');	
	}	
?>

<div class="container"> 
	
	<form  role="form" method="post" class="form-horizontal" action="postjob.php">
        <div class="page-header" style="background: #f4511e"></div>
        <h3> Job Details: </h3>
          <div class="page-header" />

           
            <div class="form-group">
                <label for="desig" class="control-label col-sm-4">Job Title/ Designation:</label>
                 <div class="col-sm-5"> 
                      <input type="text" class="form-control" name="desig"  required >
                 </div>              
            </div>
            
             <div class="form-group">
                  <label for="vac_no" class="control-label col-sm-4">Total Vacancy:</label>
                  <div class="col-sm-5"> 
					<input type="text" name="vacno" required class="form-control"> 
				  </div>                 
            </div>
            
             <div class="form-group">
                <label for="job_desc" class="control-label col-sm-4">Job Description:</label>
                  <div class="col-sm-5">  
					<textarea class="form-control" rows="5" name="jobdesc" required ></textarea> 
				  </div>
            </div>
            
             <div class="form-group">
                <label for="exp" class="control-label col-sm-4">Work Experiecne:</label>
                  <div class="col-sm-5">
                       <select class="form-control" name="exp" required name="exp" id="exp">
                           <option value=""> -Select- </option>
                           <option value="Freshers">Freshers</option>
                           <option value="1">1 </option>
                           <option value="2">2 </option>
                           <option value="3">3 </option>
                           <option value="4">4 </option>
                           <option value="5">5 </option>
                           <option value="6">6 </option>
                           <option value="7">7 </option>
                           <option value="8">8 </option>
                           <option value="9">9 </option>
                           <option value="10+">10+</option>
                       </select> 
                   </div>
             </div>
             
            <div class=" form-group">
                <label for="pay-div" class="control-label col-sm-4">Basic Pay:</label>
                  <div class="col-sm-5" >
                        <input type="text" class="form-control"  name="pay" required >
                   </div>                  
            </div>
            
            <div class="form-group">
                <label for="fnarea" class="control-label col-sm-4">Functional Area/Skill:</label>
                 <div class="col-sm-5">  
					<input type="text" class="form-control"  required name="skill"> 
				</div>                           
            </div>
			
            
            
          
            <h3> Desired Candidate Profile:</h3>
            <div class="page-header" />
                <div class="form-group">
                    <label  class="control-label col-sm-4">Specify  Qualification:</label>
                    <div class="col-sm-5 ">
						<select name="ugcourse"   class=" form-control" required>
							    <option value="" label="Select">Select</option>
								<option value="SSC">SSC</option>
								<option value="HSC">HSC</option>
							    <option value='Bangla'> Bangla </option>
								<option value='BBA'> BBA </option>
								<option value='Chymesty'> Chymestry </option>
								<option value='CSE'> CSE </option> 					   
								<option value='Civil'> Civil </option> 					   
								<option value='English'> English </option> 					   
								<option value='Economics'> Economics </option> 					   
								<option value='EEE'> EEE </option> 					   
								<option value='ICE'> ICE </option> 					   
								<option value='Pharmacy'> Pharmacy </option> 					   
								<option value='Mathametics'> Mathametics </option> 					   
								<option value='Mechanical'> Mechanical </option> 					   
								<option value='Political Science'> Political Science </option> 					   
								<option value='Journalism'> Journalism </option> 					   
								<option value='Law'> Law </option> 					   
								<option value='Islamic History'> Islamic History </option> 					   
								<option value='Statistic '> Statistic </option> 
								<option value="Other">Other</option>
						</select>
                    </div>
                </div>
                <div class="form-group">
                    <label  class="control-label col-sm-4">Specify PG Qualification:</label>
                    <div class="col-sm-5">
                        <select name="pgcourse"   class="form-control" >
                            <option value="">Select</option>
                              <option value="Not Pursuing Post Graduation"> Not Required</option>
                              <option value="CA">CA</option>
                              <option value="CS">CS</option>
                              <option value="ICWA (CMA)">ICWA (CMA)</option>
                              <option value="Integrated PG">Integrated PG</option>
                              <option value="LLM">LLM</option>
                              <option value="M.A">M.A</option>
                              <option value="M.Arch">M.Arch</option>
                              <option value="M.Com">M.Com</option>
                              <option value="M.Ed">M.Ed</option>
                              <option value="M.Pharma">M.Pharma</option>
                              <option value="M.Sc">M.Sc</option>
                              <option value="M.Tech">M.Tech</option>
                              <option value="MBA/PGDM">MBA/PGDM</option>
                              <option value="MCA">MCA</option>
                              <option value="MS">MS</option>
                              <option value="PG Diploma">PG Diploma</option>
                              <option value="MVSC">MVSC</option>
                             <option value="MCM">MCM</option>
                             <option value="Other">Other</option>
                         </select> 
                    </div>
                </div>
                <div class="form-group">
                    <label for="profile" class="control-label col-sm-4">Desired Candidate Profile</label>
                    <div class="col-sm-5">
						<textarea  rows="5" name="profile" class="form-control" required ></textarea>
					</div>
                </div>
                <div class="page-header" />
                
           <div class="container row">
                <div class="col-sm-4"></div>
                <div class="col-sm-5">
                    <div class="form-group">
                        <input name="submit" type="submit" class="btn btn-block btn-primary" value="Send"> </div>
                </div>
                <div class="col-sm-4"></div>
            </div>		
	</form>
</div>
<?php require_once('Footer.php'); ?>