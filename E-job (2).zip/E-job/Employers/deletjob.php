<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php require_once("config.php"); ?>
<?php
session_start();

include("checklogin.php");
check_login();
  if(isset($_GET['did']))
	{
		mysqli_query($conn, "delete from job where id='".$_GET['did']."'");
		
			{
			echo "<script>alert('Successfully Deleted!'); window.location='profile.php'</script>";
			}
	}
?>