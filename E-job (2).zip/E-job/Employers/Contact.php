<?php require_once('header.php'); ?>
<?php require_once("config.php"); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
	$Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['employes_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	
	}	
?>
	

			
		<div class='container'>
            <div class="row">
                <div class="col-sm-3"></div>
                <div class="col-sm-6">
                    
                    <h2>Share Your Opinon With Us:</h2>
                    <form method="post" action="Con_form.php">
                        <br> <br>
    <?php
		if($pid==NULL and $pass==NULL)
			{
				echo "<h3><a href='Login.php'>For comment please Log-In</a></h3>";
			}
			
			else      
				echo " 
                        <div class='form-group'>
                            <input type='text' class='form-control' required name='name' placeholder='Name....'>
                        </div>
                        <div class='form-group'>
                            <input type='email' class='form-control' required name='email' placeholder='Email....'>
                        </div>
                        <div class='form-group'>
                            <input type='text' class='form-control' required name='mobile' placeholder='Mobile....'>
                        </div>
                        <div class='form-group'>
                            <input type='text' class='form-control' required name='subject'  placeholder='About of comment....'>
                        </div>
                        <div class='form-group'>
                            
                            <textarea class='form-control' rows='6' required class='form-control' name='comment' placeholder='Your comment....'> </textarea>
                        </div>
                        <div class='form-group'>
                            <button type='submit' id='button' value='Submit' class='btn btn-block btn-primary' name='submit'>Submit</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class='col-sm-3'></div>";
		
		
		?>
        </div>
</div>
        <br><br><br>
        <br><br>
        <?php require_once('Footer.php') ?>