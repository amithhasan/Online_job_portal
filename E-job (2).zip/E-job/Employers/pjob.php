<?php require_once("../config/connection.php"); ?>
<?php require_once('header.php'); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['employes_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('location:../index');	
	}	
?>


      <section id="main-content">
          <section class="wrapper">
				<div class="row">			                	                  
                  <div class="col-md-12">
                      <div class="content-panel">
                          <table class="table table-responsive table-hover">
	                  	  	  <h4><i class="fa fa-angle-right"></i> All Posted Job </h4>
	                  	  	  <hr>
                              <thead>
                              <tr>
                                  <th>Sno.</th>
                                  <th>Designation</th>
                                  <th>Vacancy</th>
                                  <th>Experience </th>
                                  <th>Pay</th>
                                  <th>Skill</th>
                                  <th>Post Date</th>
                                  <th>Action</th>
                              </tr>
                              </thead>
                              <tbody>
                  <?php $ret=mysqli_query($conn, "select * from  job  where user_id='".$_SESSION['employes_id']."' and Status='Confirm' ");
							  $cnt=1;
							  while($row=mysqli_fetch_array($ret))
							  {?>
                              <tr>
								  <td><?php echo $cnt;?></td>
                                  <td><?php echo $row['desig'];?></td>
                                  <td><?php echo $row['vacno'];?></td>
                                  <td><?php echo $row['exp'];?></td>
                                  <td><?php echo $row['pay'];?></td>  
								  <td><?php echo $row['skill'];?></td>
								  <td><?php echo $row['postdate'];?></td>
                                  <td>
                                                                        
                                    <a href="deletjob.php?did=<?php echo $row['id'];?>"> 
                                     <button class="btn btn-danger btn-xs" onClick="return confirm('Do you really want to delete');"><i class="fa fa-trash-o "></i></button></a>
                                  </td>
                              </tr>
                              <?php $cnt=$cnt+1; }?>
                             
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
		</section>
      </section>
	  <br>
	  <br>
	  <br>
	  <br>
	  <br>
	  <br>
	  <br>
	  <br>
<?php require_once('Footer.php'); ?>