<?php require_once("config.php"); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
		$Name=$_SESSION['name'];
		$user=$_SESSION['username'];   //_SESSION is a PHP keyword
		$pass=$_SESSION['password'];   
		$pid= $_SESSION['employes_id'];
    
    }
	else{
		$user=NULL;
		$pass=NULL;
		header('location:../index');
	
	
	}	
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>E-Job Portal</title>
    <link rel="stylesheet" href="../css/bootstrap.css" >
    <link rel="stylesheet" href="../css/font-awesome.min.css" >
    <link rel="stylesheet" href="../css/style.css" >
	
    <script type="text/javascript" src="../js/jquery.js"></script>
    <script type="text/javascript" src="../js/jquery.pwdMeter.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
</head>

<body>
<div class="container">
        <br><br><br>
	    <div class="row">
            <div class="col-sm-12">
                <img class="img-responsive"  src="images/01.jpg" alt="">
            </div>
        </div>
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand">E-Job </a>
                </div>
				
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href='index'><i class="fa fa-home fa-fw"></i>&nbsp;Home</a></li>
                        <li><a href='profile'>&nbsp;Profile</a></li>
                        <li><a href='pjob'>&nbsp;Posted Job</a></li>
                        <li><a href='application'>&nbsp;Application</a></li>
                                              
                    </ul>

                    <ul class="nav navbar-nav left">
                      <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-user"></i>&nbsp;

								<?php                                         
                                
								 if($pid!=NULL and $pass!=NULL)
                                {
                                   echo $Name;
                                }
                                else
                                    echo 'Not in';                                                               

                                ?> &nbsp;<span class='caret'></span>

                            </a>

                        <ul class="dropdown-menu">
             
						<?php
														
						
							if($pid!=NULL and $pass!=NULL)
							{
								echo "<li><a href='insert_job.php'><i class='fa fa-user fa-fw'></i>&nbsp; Post Job</a></li>";
								echo "<li><a href='update_password'><i class='fa fa-user fa-fw'></i>&nbsp; Change Password </a></li>";
								echo "<li><a href='logout'><i class='fa fa-sign-out fa-fw'></i>&nbsp; Log Out</a></li>";
							}
													
							
							if($pid!=NULL and $pass!=NULL)
							{
								
							}
							
							
						?>
						
                        </ul>
                     </li>
                    </ul>
                </div>           
            </div>       
	   </nav>    
</div>
