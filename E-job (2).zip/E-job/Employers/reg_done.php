<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "e-job"; 


	$conn = mysqli_connect($servername, $username, $password, $dbname);
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$company  =  $_POST['company'];
	$name =      $_POST['name'];
	$username  = $_POST['username'];
	$mobile =    $_POST['mobile'];	
	$indtype  =  $_POST['indtype'];
	$distict  =  $_POST['distict'];
	$details  =  $_POST['details'];	
	$email  =    $_POST['email'];	
	$url  =      $_POST['url'];	
	$password = hash('sha256', $_POST['password']);   
	
		
	
	$sql= "INSERT INTO `employes`(`employes_id`, `name`,  `username`,   `company`, `email`,   `password`,  `mobile`,  `indtype`,  `distict`, `details`, `url`)	
VALUES ('', '$name',  '$username', '$company', '$email', '$password', '$mobile', '$indtype', '$distict', '$details', '$url')";
	

	if (mysqli_query($conn, $sql))
	{
		echo "<script>alert('Successfully registered!'); window.location='../Login'</script>";
	} 
	else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?> 

