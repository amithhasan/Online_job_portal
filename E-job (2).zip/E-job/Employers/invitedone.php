<?php require_once("header.php"); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
		$Name=$_SESSION['name'];
		$user=$_SESSION['username'];   //_SESSION is a PHP keyword
		$pass=$_SESSION['password'];   
		$pid= $_SESSION['employes_id'];
    
    }
	else
	{
		$user=NULL;
		$pass=NULL;
		header('location:../index');
	}

    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "e-job"; 


	$conn = mysqli_connect($servername, $username, $password, $dbname);

	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$usr_id    	=    $_POST['usrid'];
	$date    	=    $_POST['bdate'];
	$time    	=    $_POST['time'];
	$attach    	=    $_POST['attach'];
		
	
	$sql= "INSERT INTO `jobinvite`(`id`, `usr_id`, `c_id`, `time`, `date`, `attach`) VALUES  ('', '$usr_id',	'$pid','$time', '$date' , '$attach')";
	
	
	
	if (mysqli_query($conn, $sql)) 
	{
		echo "<script>alert('Successfully Added!'); window.location='profile'</script>";
	} 
	else 
	{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?> 