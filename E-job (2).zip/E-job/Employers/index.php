<?php require_once('header.php'); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
		$Name=$_SESSION['name'];
		$user=$_SESSION['username'];   //_SESSION is a PHP keyword
		$pass=$_SESSION['password'];   
		$pid= $_SESSION['employes_id'];
    
    }
	else{
		$user=NULL;
		$pass=NULL;
		$_SESSION['UserType']=NULL;
		header('location:../index');	
	}	
?>
<?php
error_reporting(0);
include("config.php");
?>


<div class="container">
   
   <form  method="post" action="index.php" >	
     <div class="row">
		<div class="col-sm-6">		<!--Here Title price-->
            <div class="form-group">
                 <h3 for="to">Title :</h3>
                <input name="to" type="txt"  class="form-control" value="<?php echo $_REQUEST["to"]; ?>" />
            </div>
        </div>
       
		<div class="col-sm-6">		<!--Here Selet Division-->
			<div class="form-group">
				<h3 for="sel1">Location:</h3>
				<select name="dist" class="form-control" id="sel1">
					<option value="">-----------------</option>
					<?php
						$sql = "SELECT * from basic_info GROUP BY dist ORDER BY dist";
						$sql_result =mysqli_query ($conn, $sql )or die ('request "Could not execute SQL query" '.$sql);
						while ($row = mysqli_fetch_array($sql_result)) 
						{
							echo "<option value='".$row["dist"]."'".($row["dist"]==$_REQUEST["dist"] ? " selected" : "").">".$row["dist"]."</option>";
						}
					?>
				 </select>
			</div>
		</div> 
           					
            <div class=" container row">
                <div class="col-sm-4"></div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <input name="submit" type="submit" class="btn btn-block btn-primary" value="Search"> </div>
                </div>
                <div class="col-sm-4"></div>
            </div>			
        </div>	
    </form>
    	
		<div class="panel-heading">
                <h4 class="panel-title">
                   <a  style="color: #337AD4" href="advance_search.php">Advance Search </a>
                </h4> 
        </div>	
			
</div>






<?php
	
	if ($_REQUEST["dist"]<>'') 
    {
        $search_title = " AND dist='".$_REQUEST["dist"]."'";	
    }					
	
    if ( $_REQUEST["to"]<>'') 
    {
        $sql = "Select users.name, users.email,basic_info.dist, 
		users.user_id,experience.skill,experience.duration, education.honsub,education.mastsub,images.userPic from users
		inner join refarence on users.user_id = refarence.ruid
		inner join images on refarence.ruid = images.imuid
		inner join experience on images.imuid = experience.exuid
		inner join education on experience.exuid = education.euid
		inner join basic_info on education.euid = basic_info.uid where skill or duration like  '%".$_REQUEST["to"]."%'".$search_title;
    } 
  
    else 
    {
        $sql = "Select users.name, users.email,basic_info.dist, 
		users.user_id,experience.skill,experience.duration, education.honsub,education.mastsub,images.userPic from users
		inner join refarence on users.user_id = refarence.ruid
		inner join images on refarence.ruid = images.imuid
		inner join experience on images.imuid = experience.exuid
		inner join education on experience.exuid = education.euid
		inner join basic_info on education.euid = basic_info.uid where user_id >0".$search_title;
    }
	

    $sql_result = mysqli_query ($conn, $sql) or die ('request "Could not execute SQL query" '.$sql);
    if (mysqli_num_rows($sql_result)>0) 
    {
        while ($row = mysqli_fetch_array($sql_result)) 
        {

			echo "<div class='container'>
                <div class='row'>
                    <div class='col-sm-6'>
                        <img class='img-responsive' width='240' height='320'    src='../JobSeeker/account/user_images/$row[userPic]' title='$row[name]'>
                    </div>

                    <div class='col-sm-6'>
                        <div class='product '>								

                            <div class='pa'>
								<h3><b>Name :</b> $row[name]  <br></h3> 
                                <h4><b>Distric :</b> $row[dist]  <br></h4>  
								<b>Study  :</b> $row[honsub] <br>
                                <h4><b>Skill :</b> $row[skill]  <br></h4> 
								
                                <b>Experience :</b> $row[duration] <br>
                                
                                						  
                            </div>
							
							<br>
							
                            <div class='p_title'>	
							
						
							
                        <a  href='user?p_id=".$row['user_id']."  ' class='btn btn-default '>Details</a>
								
				
                            </div><br>

                        </div><hr>

                    </div>
                </div>
            </div>";
			?> 
			
			<?php
        }
    } 
    
	
		/*  <a  href='user?p_id=".md5($row['user_id'])."  ' class='btn btn-default '>Details</a>  */
	
	
	else 
		{
			?>
		<div class='alert alert-danger alert-dismissible' role='alert'>
            <button type='button' class='close'  data-dismiss='alert' aria-label='Close'><span
                    aria-hidden='true'>&times;</span></button>
           <p style='font-size: 20px'><strong>Oops!</strong> No Result Found</p>
        </div>       
			<?php	
		}
	
	
	
 ?>



<?php require_once('Footer.php'); ?>		