<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['employes_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('location:../index');	
	}	
?>
<?php
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "e-job"; 


	$conn = mysqli_connect($servername, $username, $password, $dbname);
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$desig  =  $_POST['desig'];
	$vacno  =  $_POST['vacno'];
	$jobdesc=  $_POST['jobdesc'];
	$exp  =    $_POST['exp'];
	$pay  =    $_POST['pay'];
	$skill  =  $_POST['skill'];
	$ugcourse=  $_POST['ugcourse'];
	$pgcourse=  $_POST['pgcourse'];
	$profile  = $_POST['profile'];
	$status="Pending";
	$date=date('d-m-y');
	
	$sql="INSERT INTO `job`(`id`, `user_id`, `desig`, `vacno`, `jobdesc`, `exp`, `pay`, `skill`, `ugcourse`, `pgcourse`, `profile`, `status`,`postdate`) 
	VALUES('', '$pid', '$desig', '$vacno', '$jobdesc', '$exp', '$pay', '$skill', '$ugcourse', '$pgcourse', '$profile', '$status', '$date')";
	
	if (mysqli_query($conn, $sql))
	{
		echo "<script>alert('Successfully Post!'); window.location='profile.php'</script>";
	} 
	else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?>