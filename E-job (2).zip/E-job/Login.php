<?php require_once('header.php'); ?>
<div class="container">
    <div id="login-form">
        <form role="form" action='action_check' method="post">
           <div class="col-sm-3"></div>
		   <div class="col-sm-6">

                <div class="form-group">
                    <h2 class="">Sign In.</h2>
                </div>

                <div class="form-group">
                    <hr />
                </div>

                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
                        <input type="email" required name="email" class="form-control" placeholder="Email" maxlength="40" />
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
                        <input type="password" required name="password" class="form-control" placeholder="Password" />
                    </div>
                </div>
				
				<div class="form-group">
					
                      <strong>User Type :</strong>
                    
                    <div class="form-group">
						<select class="form-control" name="cmbUser" required>
							<option value="" selected="selected">Select</option>
							<option value="JobSeeker">JobSeeker</option>
							<option value="Employer">Employer</option>								
						</select>
					</div>
				</div>

                <div class="form-group">
                    <hr />
                </div>

                <div class="form-group">
                    <button type="submit" value="login" class="btn btn-block btn-primary" name="btn-login">Sign In</button>
                </div>

                
                
                </div>
                </form>
            </div>     
    </div>
<?php require_once('Footer.php'); ?>


      
