<?php

$host = "localhost";
$user  = "root";
$password =  "";
$database1 = "e-job";

$db1 = mysqli_connect($host, $user, $password, $database1);

$keyword= $_GET['key'];
if($keyword==""){
    echo " <div class='alert alert-warning alert-dismissible' role='alert'>
            <button type='button' class='close'  data-dismiss='alert' aria-label='Close'><span
                    aria-hidden='true'>&times;</span></button>
           <p style='font-size: 20px'><strong>Oops!</strong> Please enter a search term</p>
        </div>";

}
else{
$query = "select * from employes inner join job on employes.employes_id=job.user_id   where desig LIKE '%".$keyword."%' or job.skill LIKE '%".$keyword."%' or employes.distict LIKE '%".$keyword."%'" ;
$result = mysqli_query($db1, $query);

if (mysqli_num_rows($result) == 0)
{
    echo "<div class='alert alert-danger alert-dismissible' role='alert'>
            <button type='button' class='close'  data-dismiss='alert' aria-label='Close'><span
                    aria-hidden='true'>&times;</span></button>
           <p style='font-size: 20px'><strong>Sorry!</strong> No jobs found matching your search, try something else</p>
        </div>";
}
else {
?>
    <html>
    <div class="table-responsive">
        <table class="table table-striped">
            <th>Company</th>
            <th>Position</th>
            <th>Division</th>
            <th>Skill</th>
            <th>Post Date</th>
            <?php
    echo "<h3 style='color:green'> Search Results Matching :" . $keyword . "</h3> ";

    while ($row = mysqli_fetch_array($result)) 
	{
        //$query2 = mysqli_query($db1, "select * from employer where eid = '$row[eid]'");
        //$r2 = mysqli_fetch_array($query2)
        echo " <tr> ";
        echo "<td>" . $row['company']."</td>";
        echo "<td>" . $row['desig'] . "</td>";     
        echo "<td>" . $row['distict']."</td>";            
		echo "<td>" . $row['skill'] . "</td>";
		echo "<td>" . $row['postdate']."</td>";  
        echo "</tr>";
    }
    echo "<h4> <a href='login.php'>Login to view more</a> </h4>";
    }

    }     ?> </table>
    </div>

    </html>