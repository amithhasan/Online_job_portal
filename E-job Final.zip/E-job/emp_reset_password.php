<?php
	if(isset($_POST["reset-password"])) {
		$conn = mysqli_connect("localhost", "root", "", "e-job");
		$sql = "UPDATE `employes` SET `password` = '" .hash('sha256', $_POST['member_password']). "' WHERE `username` = '" . $_GET["name"] . "'";
		$result = mysqli_query($conn,$sql);
		$success_message = "Password is reset successfully.";
		echo"<script>alert('Password is reset successfully'); window.location='index'</script> ";
		
	}
?>
<!DOCTYPE HTML>
<html>
    <head>
	<link href="demo-style.css" rel="stylesheet" type="text/css">
	<script>
	function validate_password_reset() {
		if((document.getElementById("member_password").value == "") && (document.getElementById("confirm_password").value == "")) {
			document.getElementById("validation-message").innerHTML = "Please enter new password!"
			return false;
		}
		if(document.getElementById("member_password").value  != document.getElementById("confirm_password").value) {
			document.getElementById("validation-message").innerHTML = "Both password should be same!"
			return false;
		}
		
		return true;
	}
	</script>
	</head>
<body>
<center>
	<form name="frmReset" id="frmReset" method="post" onSubmit="return validate_password_reset();">
		<h1>Reset Password</h1>
		<?php if(!empty($success_message)) { ?>
		<div class="success_message"><?php echo $success_message; ?></div>
		<?php } ?>

		<div id="validation-message">
			<?php if(!empty($error_message)) { ?>
		<?php echo $error_message; ?>
		<?php } ?>
		</div>

		<div class="field-group">
			<div><label for="Password">Password</label></div>
			<div>
			<input type="password" name="member_password" id="member_password" class="input-field"></div>
		</div>
		
		<div class="field-group">
			<div><label for="email">Confirm Password</label></div>
			<div><input type="password" name="confirm_password" id="confirm_password" class="input-field"></div>
		</div>
		
		<div class="field-group">
			<div><input type="submit" name="reset-password" id="reset-password" value="Reset Password" class="form-submit-button"></div>
		</div>	
	</form>
	</center>
</body>
</html>
				