<?php require_once("config/connection.php"); ?>

            <?php

session_start();
$UserType=$_POST['cmbUser'];

if($UserType=="JobSeeker")
{
	$login = mysqli_query($conn, "SELECT * FROM users WHERE(email = '".$_POST['email']."') and (password ='".hash('sha256', $_POST['password'])."')");
	if (mysqli_num_rows($login) == 1) 
	{
		$row=mysqli_fetch_array($login);
			$_SESSION['name'] =     $row['name'];
			$_SESSION['username'] = $_POST['username'];
			$_SESSION['password']=  $_POST['password'];
			$_SESSION['user_id']=   $row['user_id'];
			header('Location: JobSeeker/index');
			  
	}
	else 
	{ 
			$_SESSION['username'] = NULL;
			$_SESSION['password']=NULL;
			$_SESSION['user_id']=NULL;
			echo"<script>alert('Error Username Or Password'); window.location='login'</script> ";
	}
}	
else 
{
		
	$login = mysqli_query($conn, "SELECT * FROM employes WHERE(email = '".$_POST['email']."') and (password ='". hash('sha256', $_POST['password'])."')");
	if (mysqli_num_rows($login) == 1) 
	{
		$row=mysqli_fetch_array($login);		   
			$_SESSION['name'] =     $row['name'];
			$_SESSION['username'] = $_POST['username'];
			$_SESSION['password']=  $_POST['password'];
			$_SESSION['employes_id']=   $row['employes_id'];

			
			header('Location: Employers/index');			  
						  
	}
	else 
	{ 
			$_SESSION['username'] = NULL;
			$_SESSION['password']=NULL;
			$_SESSION['employes_id']=NULL;
			echo"<script>alert('Error Username Or Password'); window.location='login'</script> ";
			
			
	}
}



?>