<?php

session_start();
if ( !isset($_SESSION['username']) || !isset($_SESSION['password']) ) {
 header('Location: index');
}
?>
<?php


session_start();
unset($_SESSION['username']);
session_destroy();
header('Location: ../index');

?>
