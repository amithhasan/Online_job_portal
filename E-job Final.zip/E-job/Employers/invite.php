<?php require_once("header.php"); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['employes_id'];
    
    }
	else{
		$user=NULL;
		$pass=NULL;
		header('location:../index');	
	}	
		
?>
<!DOCTYPE html>
<html lang='en'>
<head>

	<link href='css/bootstrap.css' 			rel='stylesheet'>			</link>
	<link href='css/style.css' 				rel='stylesheet'>		    </link>
	<link id='themeLink' href='css/themes/blue.css' rel='stylesheet'></link>
	<link type='text/css' href='css/tabbed.css' rel='stylesheet' </link>
	<link media='screen' href='css/blue.css' type='text/css' rel='stylesheet'> </link>
	
	
    <script src='js/jquery.min.js' type='text/javascript'></script>
    <script src='js/bootstrap.min.js'></script>
	
    <script src='same.js'></script>
	
	<link rel='stylesheet' href='css/font-awesome.min.css' />	
	<script type='text/javascript' src='js/formden.js'></script>
	<script type='text/javascript' src='bootstrap-datepicker.min.js'></script>
	<link rel='stylesheet' href='bootstrap-datepicker3.css'/>	
	
</head>
<body>
		<br>
		<br>
		<br>
		<br>
		<br>
	
<div class='container'>	  
<div id='home'  class='tab-pane fade in active'>
	  <div id='content'>		
		<form   class='form-horizontal' action='invitedone.php' method='post' role='form' > 
					 
		
			
			<input type='hidden' name='usrid' value='<?php echo $_GET['u_id'] ?>  ' class='form-control' required placeholder='Mobile Number'>
			
			<div class="form-group">
                <label  class="col-sm-4">Job Attachment:</label>
                  <div class="col-sm-8">  
					<textarea class="form-control" rows="5" name="attach" required ></textarea> 
				  </div>
            </div>
			
			<div class='form-group'>
			  <label class='col-sm-4'>Interview Time <span class='red' >*</span> </label>
			  <div class='col-sm-8'>
				<input type='text' name='time' class='form-control' required placeholder='Mobile Number'>
			  </div>
			</div>
			
			
		<div class='form-group bootstrap-iso'>
			  <label class='col-sm-4'>Interview Date <span class='red' >*</span> </label>
			<div class='col-sm-8'>				
					<div class='input-group' id='datetimepicker'>
						<input class='form-control' id='date' required name='bdate' placeholder='MM/DD/YYYY' type='text'/>
						<span class='input-group-addon'>
							<span class='glyphicon glyphicon-calendar'></span>
						</span>
					</div>
				
			</div>
		</div>
			
		<script>
			$(document).ready(function(){
				var date_input=$('input[name=bdate]'); 
				var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() :'body';
				date_input.datepicker({
					format: 'mm/dd/yyyy',
					container: container,
					todayHighlight: true,
					autoclose: true,
				})
			})
		</script>
		
		<div class='form-group'>
			<button type='submit' class='btn btn-block btn-primary' name='Submit'>Submit</button>
		</div>
				
        </form>
		           
		</div>
		</div>        
   </div>
      <hr>
     
</div>    	
	
    <script src="js/script.js"></script>
  </body>
  
</body>
</html>