<?php require_once('../header.php') ?>
<!DOCTYPE html">
<html lang="en">
<head>

    <meta charset="utf-8">
    <title>E-Job Portal</title>
    <link rel="stylesheet" href="../css/bootstrap.css" >
    <link rel="stylesheet" href="../css/font-awesome.min.css" >
    <link rel="stylesheet" href="../css/style.css" >
	
    <script type="text/javascript" src="../js/jquery.js"></script>
    <script type="text/javascript" src="../js/jquery.pwdMeter.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
</head>
		<title>Registration</title>		
		<script type="text/javascript">
		$(document).ready(function(){
		
		$("#password").pwdMeter();
		
		});
		</script>
		<style>
		.veryweak{
		color:#B40404;
		}
		.weak{
		color:#DF7401;
		}
		.medium{
		color:#1DFE2E;
		}
		.strong{
		color:#9AFE2E;
		}
		.verystrong{
		color:#0B610B;
		}
		</style>
		<script>
				function checkemailAvailability() {
				$("#loaderIcon").show();
				jQuery.ajax({
				url: "check_availability.php",
				data:'emailid='+$("#emailid").val(),
				type: "POST",
				success:function(data){
				$("#email-availability-status").html(data);
				$("#loaderIcon").hide();
				},
				error:function (){}
				});
				}
				function checkusernameAvailability() {
				$("#loaderIcon").show();
				jQuery.ajax({
				url: "check_availability.php",
				data:'username='+$("#username").val(),
				type: "POST",
				success:function(data){
				$("#username-availability-status").html(data);
				$("#loaderIcon").hide();
				},
				error:function (){}
				});
				}
		</script>
	</head>
<body>
	<div class="container">
		<div class="row">				
			<div id="login-form">
				<form name='register' action='reg_done.php' method='post' autocomplete="off" accept-charset='UTF-8'>
					<div class="col-sm-3"></div>
					<div class="col-sm-6">
						<div class="form-group">
								<h2 class="">Register Page</h2>
						</div>
							
						<div class="form-group">
								<hr />
						</div>
						
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user-circle fa-fw"> </i></span>
								<input type="text" name="company" required class="form-control" placeholder="Company Name" maxlength="50"  />
							</div>
						</div>
							
							
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user-circle fa-fw"> </i></span>
								<input type="text" name="name" required class="form-control" placeholder="Enter Executive Name" maxlength="50"  />
							</div>
						</div>
						
								
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user fa-fw"> </i></span>
								<input type="text" name="username" id="username" value="" onBlur="checkusernameAvailability()" required class="form-control" placeholder="Username" maxlength="50"  />
							</div>  <span id="username-availability-status"></span>									
						</div>
								
						
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user-circle fa-fw"> </i></span>
								<input type="text" name="mobile" required class="form-control" placeholder="Executive Mobile" maxlength="50"  />
							</div>
						</div>
						
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
								<input type="email" name="email" id="emailid" onBlur="checkemailAvailability()" value="" required class="form-control" placeholder="Your Email" maxlength="40"  />
							</div>  <span id="email-availability-status"></span>
						</div>


				
			<div class="form-group">               
                <div class="form-group">
                <select name="indtype" id="indtype" class="form-control"  required>
                    <option selected="selected" value="">- Select an Industry -</option>
                    <option value="Accessories/Apparel/Fashion Design">Accessories/Apparel/Fashion Design</option>
                    <option value="Accounting/Consulting/Taxation">Accounting/Consulting/Taxation</option>
                    <option value="Advertising/Event Management/PR">Advertising/Event Management/PR</option>
                    <option value="Agriculture/Dairy Technology">Agriculture/Dairy Technology</option>
                    <option value="Airlines/Hotel/Hospitality/Travel/Tourism/Restaurants">Airlines/Hotel/Hospitality/Travel/Tourism/Restaurants</option>
                    <option value="Animation / Gaming">Animation / Gaming</option>
                    <option value="Architectural Services/ Interior Designing">Architectural Services/ Interior Designing</option>
                    <option value="Auto Ancillary/Automobiles/Components">Auto Ancillary/Automobiles/Components</option>
                    <option value="Banking/Financial Services/Stockbroking/Securities">Banking/Financial Services/Stockbroking/Securities</option>
                    <option value="Banking/FinancialServices/Broking">Banking/FinancialServices/Broking</option>
                    <option value="Biotechnology/Pharmaceutical/Clinical Research">Biotechnology/Pharmaceutical/Clinical Research</option>
                    <option value="Brewery/Distillery">Brewery/Distillery</option>
                    <option value="Cement/Construction/Engineering/Metals/Steel/Iron">Cement/Construction/Engineering/Metals/Steel/Iron</option>
                    <option value="Ceramics/Sanitaryware">Ceramics/Sanitaryware</option>
                    <option value="Chemicals/Petro Chemicals/Plastics">Chemicals/Petro Chemicals/Plastics</option>
                    <option value="Computer Hardware/Networking">Computer Hardware/Networking</option>
                    <option value="Consumer FMCG/Foods/Beverages">Consumer FMCG/Foods/Beverages</option>
                    <option value="Consumer Goods - Durables">Consumer Goods - Durables</option>
                    <option value="Courier/Freight/Transportation/Warehousing">Courier/Freight/Transportation/Warehousing</option>
                    <option value="CRM/ IT Enabled Services/BPO">CRM/ IT Enabled Services/BPO</option>
                    <option value="Education/Training/Teaching">Education/Training/Teaching</option>
                    <option value="Electricals/Switchgears">Electricals/Switchgears</option>
                    <option value="Employment Firms/Recruitment Services Firms">Employment Firms/Recruitment Services Firms</option>
                    <option value="Entertainment/Media/Publishing/Dotcom">Entertainment/Media/Publishing/Dotcom</option>
                    <option value="Export Houses/Textiles/Merchandise">Export Houses/Textiles/Merchandise</option>
                    <option value="FacilityManagement">FacilityManagement</option>
                    <option value="Fertilizers/Pesticides">Fertilizers/Pesticides</option>
                    <option value="FoodProcessing">FoodProcessing</option>
                    <option value="Gems and Jewellery">Gems and Jewellery</option>
                    <option value="Glass">Glass</option>
                    <option value="Government/Defence">Government/Defence</option>
                    <option value="Healthcare/Medicine">Healthcare/Medicine</option>
                    <option value="HeatVentilation/AirConditioning">HeatVentilation/AirConditioning</option>
                    <option value="Insurance">Insurance</option>
                    <option value="KPO/Research/Analytics">KPO/Research/Analytics</option>
                    <option value="Law/Legal Firms">Law/Legal Firms</option>
                    <option value="Machinery/Equipment Manufacturing/Industrial Products">Machinery/Equipment Manufacturing/Industrial Products</option>
                    <option value=">Mining">Mining</option>
                    <option value="NGO/Social Services">NGO/Social Services</option>
                    <option value="Office Automation">Office Automation</option>
                    <option value="Others/Engg. Services/Service Providers">Others/Engg. Services/Service Providers</option>
                    <option value="Petroleum/Oil and Gas/Projects/Infrastructure/Power/Non-conventional Energy">Petroleum/Oil and Gas/Projects/Infrastructure/Power/Non-conventional Energy</option>
                    <option value="Printing/Packaging">Printing/Packaging</option>
                    <option value="Publishing">Publishing</option>
                    <option value="Real Estate">Real Estate</option>
                    <option value="Retailing">Retailing</option>
                    <option value="Security/Law Enforcement">Security/Law Enforcement</option>
                    <option value="Shipping/Marine">Shipping/Marine</option>
                    <option value="Software Services">Software Services</option>
                    <option value="Steel">Steel</option>
                    <option value="Strategy/ManagementConsultingFirms">Strategy/ManagementConsultingFirms</option>
                    <option value="Telecom Equipment/Electronics/Electronic Devices/RF/Mobile Network/Semi-conductor">Telecom Equipment/Electronics/Electronic Devices/RF/Mobile Network/Semi-conductor</option>
                    <option value="Telecom/ISP">Telecom/ISP</option>
                    <option value="Tyres">Tyres</option>
                    <option value="WaterTreatment/WasteManagement">WaterTreatment/WasteManagement</option>
                    <option value="Wellness/Fitness/Sports">Wellness/Fitness/Sports</option>
                </select>
                </div>
            </div>
			
			<div class="form-group">               
                <div class="form-group">
					<select name="distict" class="form-control"  required>
                           <option value="" selected="selected">--Select Division --</option>
						   <option value="Dhaka">Dhaka</option>  
						   <option value="Rajshahi">Rajshahi</option>  
						   <option value="Chittagong">Chittagong</option> 
                           <option value="Shylet">Shylet</option>                     
						   <option value="Khulna">Khulna</option>						   
						   <option value="Rangpur">Rangpur</option>			   
                           <option value="Dinajpur">Dinajpur</option> 					   
                   </select>
				</div>
            </div>
			
			
					
			<div class="form-group">
				<div class="form-group">
					<textarea placeholder="Describe your company" name="details" class="form-control" rows="5" required ></textarea>
				</div>
			</div>
			
			<div class="form-group">
				<div class="input-group">
						<span class="input-group-addon"><i class="fa fa-user-circle fa-fw"> </i></span>
						<input type="text" name="url" required class="form-control" placeholder="www.abc.com" maxlength="50"  />
				</div>
			</div>
						
								
						
			<div class="form-group">
				<div class="input-group">
						<span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
						<input type="password" id="password" required name="password" class="form-control" placeholder="Enter Password"/>											
				</div>  <span id="pwdMeter" class="neutral"></span>
			</div>
										
						
						<hr/>
						
										
			<div class="form-group">
				<button type="submit" class="btn btn-block btn-primary" name="Submit">Sign Up</button>
			</div>	
			
					</div>
				</form>
			</div>
		</div>
	</div>
					
	<br><br>
					
	<?php require_once('Footer.php'); ?>