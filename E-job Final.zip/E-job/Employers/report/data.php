<?php require_once("../session.php"); ?>
<?php require_once("../functions.php"); ?>
<?php 
    if(logged_in())
    {
		$Name=$_SESSION['name'];
		$user=$_SESSION['username'];   //_SESSION is a PHP keyword
		$pass=$_SESSION['password'];   
		$pid= $_SESSION['employes_id'];
    
    }
	else{
		$user=NULL;
		$pass=NULL;
		header('location:../index');
	
	
	}	
?>
<?php
include_once("db_connect.php");
// initilize all variables
$params = $columns = $totalRecords = $data = array();
$params = $_REQUEST;
//define index of columns
$columns = array( 
	0 =>'name',
	1 =>'email', 
	2 =>'dist', 
	3 =>'mobile',	
	4 =>'skill'	
);
$where = $sqlTot = $sqlRec = "";
// getting total number records from table without any search
$sql =  "  Select users.name, users.email, basic_info.pdist, basic_info.mobile, experience.skill, experience.duration,users.user_id, apply.u_id, apply.c_id , education.honors,education.mastars from users
		inner join refarence on users.user_id = refarence.ruid
		inner join apply on refarence.ruid = apply.c_id
		inner join experience on apply.c_id = experience.exuid
		inner join education on experience.exuid = education.euid
		inner join basic_info on education.euid = basic_info.uid   where c_id='".$_SESSION['employes_id']."' ";



$sqlTot .= $sql;
$sqlRec .= $sql;
$sqlRec .=  " ORDER BY name";
$queryTot = mysqli_query($conn, $sqlTot) or die("database error:". mysqli_error($conn));
$totalRecords = mysqli_num_rows($queryTot);
$queryRecords = mysqli_query($conn, $sqlRec) or die("error to fetch employees data");
// iterate on results row and create new index array of data
while( $row = mysqli_fetch_row($queryRecords) ) { 
	$data[] = $row;
}	
$json_data = array(
		"draw"            => 1,   
		"recordsTotal"    => intval( $totalRecords ),  
		"recordsFiltered" => intval($totalRecords),
		"data"            => $data
		);
// send data as json format
echo json_encode($json_data);  
?>