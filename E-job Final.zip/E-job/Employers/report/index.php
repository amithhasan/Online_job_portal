<?php 
include('header.php');
?>

<link rel="stylesheet" type="text/css" href="datatables.min.css"/>
<script type="text/javascript" src="datatables.min.js"></script>
<script type="text/javascript" src="script/script.js"></script>
<?php include('container.php');?>
<style>
 .dataTables_length {
  	margin-top:20px;
  }
  div.dt-buttons {
    position: relative;
    float: left;
    margin-left: 20px;
	margin-top:12px;
	font-size:16px;
	font-weight:bold;
 }
 .dataTables_filter {
	 margin-top:20px;
 }
</style>
<div class="container">
	<h2>User Report </h2>	
	<div class="row">		
		<table id="example" class="display" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Distict</th>               
                <th>Mobile</th>                             
                <th>Skill</th>               
            </tr>
        </thead>       
    </table>	
	</div>	
		
</div>
<?php include('footer.php');?>

