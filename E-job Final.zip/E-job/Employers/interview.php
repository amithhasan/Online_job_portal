<?php require_once("header.php"); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['employes_id'];
    
    }
	else{
		$user=NULL;
		$pass=NULL;
		header('location:../index');	
	}	
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="script/datatables.min.css"/>
	<link rel="stylesheet" href="script/bootstrap.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
	<script src="script/jquery.min.js"></script>
	<script src="script/bootstrap.min.js"></script>
	<script type="text/javascript" src="script/datatables.min.js"></script>
	<script type="text/javascript" src="script/script.js"></script>
<style>
 .dataTables_length {
  	margin-top:20px;
  }
  div.dt-buttons {
    position: relative;
    float: left;
    margin-left: 20px;
	margin-top:12px;
	font-size:16px;
	font-weight:bold;
 }
 .dataTables_filter {
	 margin-top:20px;
 }
</style>
</head>
<body>
<div class="container">
	<div class="row">		
		<table id="example" class="display" width="100%" cellspacing="0">
			<thead>
				<tr>
					<th>Name</th>
					<th>Email</th>
					<th>Distict</th>               
					<th>Mobile</th>                             
					<th>Skill</th>               
				</tr>
			</thead>       
		</table>	
	</div>			
</div>
</body>
</html>