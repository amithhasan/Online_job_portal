<div id="page">
<div class="container footer">
			<div class="row">
				<div class="col-sm-12 col-md-12">
					<div class="col-md-3 col-sm-6 col-xs-12 b">
						<h3>Company</h3>
						<ul style="list-style-type:none">
							<li><a href="#">About Us</a></li>
							<li><a href="#">Careers</a></li>
							<li><a href="#">Feature Tour</a></li>
							<li><a href="#">Pricing</a></li>
							<li><a href="#">Team</a></li>
						</ul>
					</div>
					
					<div class="col-md-3 col-sm-6 col-xs-12  b">
						<h3>Support</h3>
						<ul style="list-style-type:none">
							<li><a href="#">Knowledge Base</a></li>
							<li><a href="#">24/7 Call Support</a></li>
							<li><a href="#">Video Demos</a></li>
							<li><a href="#">Terms of Use</a></li>
							<li><a href="#">Privacy Policy</a></li>
						</ul>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 c">
						<h3>Contact Us</h3>
						<h4>
						<a href="">info@jobportal.com</a>
						<br>
						<h5>198 West 21th Street,</h5>
						<h5>Rajshahi, Bangladesh </h5>
						<a href="tel:+8801755455511">+017 55 455 511</a>
						</h4>
						
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 d">
						<h3>Follow Us</h3><br><br>
						<ul style="list-style-type:none">
							<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a> </li>
							<li><a href="#"><i class="fa fa-twitter"  aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-skype"    aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-youtube"  aria-hidden="true"></i></a></li>
						</ul>
					</div>
				</div>				
			</div>
		</div>
		
		<div class="row f">
			<div class="col-sm-9  left">
				<p><small>&copy; 2017 <a href="#"> Guide</a> All Rights Reserved.</small></p>
			</div>
			
			<div class="col-sm-3 right">
				<p ><small>Designed by &copy;Amit</small></p>
			</div>
		</div>
	</div>
	</body>
</html>
