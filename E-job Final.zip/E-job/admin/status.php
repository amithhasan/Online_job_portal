<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
$Id = $_GET['sid'];

$con = mysql_connect("localhost","root");

mysql_select_db("e-job", $con);

$sql = "Update job set status='Confirm' where id=".$Id."";
mysql_query($sql,$con);
mysql_close($con);
echo '<script type="text/javascript">alert("Employer Request Confirmed");window.location=\'manage-users.php\';</script>';
?>
</body>
</html>