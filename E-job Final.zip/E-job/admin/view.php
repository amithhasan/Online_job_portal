<?php
session_start();
$mysql_hostname ="localhost";
include'dbconnection.php';
include("checklogin.php");
check_login();
  if(isset($_GET['did']))
	{
		mysql_query("delete from job where id='".$_GET['did']."'");
		
			{
			echo "<script>alert('Successfully Deleted!'); window.location='manage-users.php'</script>";
			}
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Admin | Manage Users</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
  </head>
<body>
 <section id="container" >
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <a href="#" class="logo"><b>Admin Dashboard</b></a>
            <div class="nav notify-row" id="top_menu">
               
                         
                   
                </ul>
            </div>
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>
<aside>
		<div id="sidebar"  class="nav-collapse ">
			<ul class="sidebar-menu" id="nav-accordion">
					  
			<p class="centered"><a href="#"><img src="assets/img/ui-sam.jpg" class="img-circle" width="60"></a></p>
			<h5 class="centered"><?php echo $_SESSION['login'];?></h5>
							
			<li class="mt">
				<a href="change-password.php"><i class="fa fa-file"></i><span>Change Password</span></a>
			</li>
			<li class="sub-menu">
				<a href="manage-users.php" ><i class="fa fa-users"></i><span>Manage Users</span></a>                   
			</li>
			<li class="sub-menu">
				<a href="employpost.php"><i class="fa fa-users"></i><span>Employee</span></a>                   
			</li> 
					  
						 
		   </ul>
		</div>
</aside>

<section id="main-content">
  <section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> Employee </h3>
	<div class="row">
		<div class="col-md-12">
           <div class="content-panel">
							
			<?php
			
				$query  = "select * from employes inner join job on employes.employes_id=job.user_id where  status='Pending' and id='".$_GET['vid']."'";
				$query_data = mysql_query($query);
					while($row = mysql_fetch_array($query_data))
					{	
			?>	
								
					<h3 style="padding:15px;background-color:#C44D2D;color:white;height:50px;"><b> JOB Details</b> </h3>
									<div class="table-responsive">
										<table class="table table-striped table-advance table-hover">
											<tbody>
												<tr>
													<th width="200"> Name </th>
													<td><?php echo $row['name'];?></td>
												</tr>
												<tr>
													<th> Email </th>
													<td><?php echo $row['email'];?>  </td>
												</tr>
												<tr>
													<th> Mobile </th>
													<td><?php echo $row['mobile'];?>  </td>
												</tr>
												<tr>
													<th> Company Name </th>
													<td><?php echo $row['company'];?>  </td>
												</tr>
												<tr>
													<th> Post </th>
													<td><?php echo $row['desig'];?>  </td>
												</tr>
												<tr>
													<th> Specify UG Qualification: </th>
													<td><?php echo $row['ugcourse'];?>  </td>
												</tr>
												<tr>
													<th> Specify PG Qualification: </th>
													<td><?php echo $row['pgcourse'];?>  </td>
												</tr>
												<tr>
													<th> Total Vacancy </th>
													<td><?php echo $row['vacno'];?>  </td>
												</tr>
												<tr>
													<th> Job Description: </th>
													<td><?php echo $row['jobdesc'];?>  </td>
												</tr>
												<tr>
													<th> Work Experiecne: </th>
													<td><?php echo $row['exp'];?> Years </td>
												</tr>
												<tr>
													<th> Functional Area/Skill: </th>
													<td><?php echo $row['skill'];?> Years </td>
												</tr>
												<tr>
													<th> Basic Pay: </th>
													<td><?php echo $row['pay'];?> Years </td>
												</tr>
												<tr>
													<th> Industry Type </th>
													<td> <?php echo $row['indtype'];?> </td>
												</tr>
												
												<tr>
													<th> Division </th>
													<td><?php echo $row['distict'];?>  </td>
												</tr>
												<tr>
													<th> Company Details </th>
													<td><?php echo $row['details'];?>  </td>
												</tr>
												<tr>
													<th> Website </th>
													<td><a href="<?php echo $row['url'];?>"><?php echo $row['url'];?></a></td>
												</tr>
												<tr>
													<th> Post Date: </th>
													<td><?php echo $row['postdate'];?></td>
												</tr>
												
											</tbody>
										</table>
									</div><br/>
						<a href="status.php?sid=<?php echo $row['id'];?>" class="btn btn-info" role="button">Approve</a>		
						
						
						<?php 
						}
						?>
				</div>		
			</div>		
		</div>		
</section>
      </section>
</section>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="assets/js/common-scripts.js"></script>
  <script>
      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>