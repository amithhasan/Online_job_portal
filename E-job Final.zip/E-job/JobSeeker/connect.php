<?php 

$connect = mysqli_connect("localhost", "root", "", "e-job");
?>