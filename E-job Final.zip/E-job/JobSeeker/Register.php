<?php require_once('../header.php') ?>
<!DOCTYPE html">
<html lang="en">
	
<head>
    <meta charset="utf-8">  
    <link rel="stylesheet" href="../css/bootstrap.css" >
    <link rel="stylesheet" href="../css/font-awesome.min.css" >
    <link rel="stylesheet" href="../css/style.css" >
	
    <script type="text/javascript" src="../js/jquery.js"></script>
    <script type="text/javascript" src="../js/jquery.pwdMeter.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>



		<title>Registration</title>		
		<script type="text/javascript">
		$(document).ready(function(){
		
		$("#password").pwdMeter();
		
		});
		</script>
		<style>
		.veryweak{
		color:#B40404;
		}
		.weak{
		color:#DF7401;
		}
		.medium{
		color:#1DFE2E;
		}
		.strong{
		color:#9AFE2E;
		}
		.verystrong{
		color:#0B610B;
		}
		</style>
		<script>
				function checkemailAvailability() 
				{
					$("#loaderIcon").show();
					jQuery.ajax({
					url: "check_availability.php",
					data:'emailid='+$("#emailid").val(),
					type: "POST",
					success:function(data){
					$("#email-availability-status").html(data);
					$("#loaderIcon").hide();
					},
					error:function (){}
					});
				}
				function checkusernameAvailability() 
				{
					$("#loaderIcon").show();
					jQuery.ajax({
					url: "check_availability.php",
					data:'username='+$("#username").val(),
					type: "POST",
					success:function(data){
					$("#username-availability-status").html(data);
					$("#loaderIcon").hide();
					},
					error:function (){}
					});
				}
		</script>
	</head>
<body>
	<div class="container">
		<div class="row">				
			<div id="login-form">
				<form name='register' action='reg_done.php' method='post' autocomplete="off" accept-charset='UTF-8'>
					<div class="col-sm-3"></div>
					<div class="col-sm-6">
						<div class="form-group">
								<h2 class="">Register Page</h2>
						</div>
							
						<div class="form-group">
								<hr />
						</div>
							
							
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user-circle fa-fw"> </i></span>
								<input type="txt" name="name" required class="form-control" placeholder="Enter Name" maxlength="50"  />
							</div>
						</div>
							
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user fa-fw"> </i></span>
								<input type="txt" name="username" id="username" value="" onBlur="checkusernameAvailability()" required class="form-control" placeholder="Username" maxlength="50"  />
							</div>  <span id="username-availability-status"></span>									
						</div>
								
						<div class="form-group">
							<select class="form-control" name="gender">
								<option value="" selected="selected">Gender</option>
								<option value="Male">Male</option>
								<option value="Female">Female</option>
								<option value="Other">Other</option>
							</select>
						</div>
								
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
								<input type="email" name="email" id="emailid" onBlur="checkemailAvailability()" value="" required class="form-control" placeholder="Your Email" maxlength="40"  />
							</div>  <span id="email-availability-status"></span>
										
						</div>
									
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
								<input type="password" id="password" required name="password" class="form-control" placeholder="Enter Password"/>											
							</div>  <span id="pwdMeter" class="neutral"></span>
						</div>
										
						
						<hr/>
						
										
						<div class="form-group">
							<button type="submit" class="btn btn-block btn-primary" name="Submit">Sign Up</button>
						</div>																		
					</div>
				</form>
			</div>
		</div>
	</div>
					
	<br><br>
					
	<?php require_once('Footer.php'); ?>