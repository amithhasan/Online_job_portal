<?php require_once("config.php"); ?>
<?php require_once('header.php'); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
	$Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('location:../index');	
	}	
?>

<section id="main-content">
          <section class="wrapper">
				<div class="row">			                	                  
                  <div class="col-md-12">
                      <div class="content-panel">
                          <table class="table table-responsive table-hover">
	                  	  	  <h4><i class="fa fa-angle-right"></i> All Posted Job </h4>
	                  	  	  <hr>
                              <thead>
                              <tr>
                                  <th>Sno.</th>
                                  <th>Company</th>
                                  <th>Distict</th>
                                  <th>Interview Date </th>
                                  <th>Interview Time</th>
                                  <th>Attach</th>
                                  <th>Url</th>

                              </tr>
                              </thead>
                              <tbody>
                  <?php $ret=mysql_query("select employes.company, employes.url, employes.distict, employes.employes_id, jobinvite.date,jobinvite.time,jobinvite.attach,jobinvite.c_id, jobinvite.usr_id from employes
					inner join jobinvite on employes.employes_id=jobinvite.c_id where usr_id='".$_SESSION['user_id']."' ");
							  $cnt=1;
							  while($row=mysql_fetch_array($ret))
							  {?>
                              <tr>
								  <td><?php echo $cnt;?></td>
								  <td><?php echo $row['company'];?></td>
								  <td><?php echo $row['distict'];?></td>
                                  <td><?php echo $row['date'];?></td>
                                  <td><?php echo $row['time'];?></td>
                                  <td><?php echo $row['attach'];?></td>
                                  <td><?php echo $row['url'];?></td>  
                                  
                              </tr>
                              <?php $cnt=$cnt+1; }?>
                             
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
		</section>
      </section>
	  <br>
	  <br>
	  <br>
	  <br>
	  <br>
	  <br>
	  <br>
	  <br>
<?php require_once('Footer.php'); ?>