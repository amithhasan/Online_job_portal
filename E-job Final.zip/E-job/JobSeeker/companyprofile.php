<?php require_once("header.php"); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('location:../index');
	
	}	
?>
<?php
	$host = "localhost";
	$user  = "root";
	$password =  "";
	$database1 = "e-job";


	$conn = mysqli_connect($host, $user, $password, $database1);

	$sql ="SELECT * from employes, 
		job where employes.employes_id=job.user_id and  id = '".$_GET['j_id']."'   ";

    
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result);
	


?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <title> <?php echo $row['company']; ?> </title>
</head>

<body>
<div class="container-fluid" id="content">
        <aside class="col-sm-3" role="complementary">
            <div class="well" id="sidebar">
			<h3><center><strong><?php echo $row['company']; ?> </strong>	</center></h3>
                <div class="thumbnail">
						
				<?php  echo" <img src='user_fallback.png'> ";  ?> 
				</div> 
			</div>
		</aside>
    <!------------------------------------------------------------------------------- -->
    
	<section class="col-sm-9">
        <div id="searchcontent">
			<div id="header">
			
		<?php  
		
			$sql2 ="SELECT * from apply where u_id='".$_SESSION['user_id']."' and c_id='".$_GET['c_id']."' and job_id = '".$_GET['j_id']."' ";
				
				$result2 = mysqli_query($conn, $sql2);
				$row1 = mysqli_fetch_array($result2);
		
		
		
			if($row1['job_id']==$row['id'])
			{
				echo "<a   class='btn btn-default disabled'>Already Apply</a>";
			}			
			
			else 	
			{
				echo	"<a  href='apply.php?j_id=".$row['id']."&c_id=".$row['user_id']." ' class='btn btn-default '>Apply</a>";		
			}
			echo "  
                <div class='tab-content'>
				<h3> <b>Basic Info</b></h3>
                   
					<table class='table table-striped'>
                                <tr>
                                    <td class='tbold'>Company Name:</td>
                                    <td>
                                         <strong> ".$row['company']." </strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td class='tbold'>Email:</td>
                                    <td>
                                        ".$row['email']."
                                    </td>
                                </tr>
								<tr>
									<td class='tbold'> Company Type </td>
									<td> ".$row['indtype']."  </td>
								</tr>
								<tr>
                                    <td class='tbold'>Distict:</td>
                                    <td>
                                         ".$row['distict']."
                                    </td>
                                </tr>								
                                <tr>
                                    <td class='tbold'>Phone:</td>
                                    <td>
                                         ".$row['mobile']."
                                    </td>
                                </tr>
								<tr>
                                    <td class='tbold'>Details:</td>
                                    <td>
                                         ".$row['details']."
                                    </td>
                                </tr>
								
								<tr>
                                    <td class='tbold'>Url:</td>
                                    <td>
                                         ".$row['url']."
                                    </td>
                                </tr>
								<tr>
									<td> Designetion </td>
									<td> ".$row['desig']."  </td>
								</tr>
								<tr>
									<td> Vacency </td>
									<td> ".$row['vacno']."  </td>
								</tr>
								<tr>
									<td> Job Discription </td>
									<td> ".$row['jobdesc']."  </td>
								</tr>
								
								                              								                             								
                            </table>";
 
					
					?>
                           
						   
				<h3> <b>Education</b></h3>
                    
				<table class='table table-striped'>
                    <?php if($row['ugcourse']!="") 
					{       echo "<tr>
                                    <td class='tbold'>UG Qualification:</td>
                                    <td>
                                         ".$row['ugcourse']."
                                    </td>
                                </tr>";
					} 
					?> 			
								
                    <?php 
							{
								echo "<tr>
									<td class='tbold'>PG Qualification: </td>								
									<td>												 
										".$row['pgcourse']."
									</td>
								</tr>";									  
                            
							} 
					?>
				</table>
							
                   <h3><b>Skills</b></h3>
                    <?php if($row['skill']!="") 
					{
						echo "<table class='table table-striped'>

                                <tr>
                                    <td class='tbold'>Skills:</td>
                                    <td>
                                         ".$row['skill']."
                                    </td>
                                </tr>							
                            </table>";
					} 
					?>
					
					
                  
                   <?php if($row['company']!="") 
					  
					{
						echo'<h3><b>Experience</b></h3>';
						echo "<table class='table table-striped'>
							
								
								
                                 <tr>
                                    <td class='tbold'>Experience (Years):</td>
                                    <td>
                                         ".$row['exp']."
                                    </td>
                                </tr>                               							
                            </table>";
					} 
					?>                    
				</div>
			</div>
		</div>
    </section>    
</div>
</body>

<link href="../css/main.css" rel="stylesheet">
<script src="../js/jquery-1.12.0.min.js"></script>
<script src="../js/bootstrap.min.js"></script>

</html>
<?php require_once("footer.php"); ?>