<?php require_once("config.php"); ?>
<?php require_once('header.php'); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
	$Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('location:../index');	
	}	
?>
<?php
error_reporting(0);

?>
<title>E-job </title>
<div class="container">
<form  method="post" action="index" >
    <div class="row">
		
		<div class="col-sm-6">		<!--Here Title price-->
            <div class="form-group">
                 <h3 for="to">Title :</h3>
                <input name="title" type="txt"  class="form-control" value="<?php echo $_REQUEST["title"]; ?>" />
            </div>
        </div>
       
		<div class="col-sm-6">		<!--Here Selet Division-->
			<div class="form-group">
				<h3 for="sel1">Location:</h3>
				<select name="distict" class="form-control" id="sel1">
					<option value="">-----------------</option>
			<?php
				$sql = "SELECT employes.distict FROM employes INNER JOIN job ON employes.employes_id=job.user_id GROUP BY distict ORDER BY distict";
				$sql_result =mysqli_query ($conn, $sql )or die ('request "Could not execute SQL query" '.$sql);
					while ($row = mysqli_fetch_array($sql_result)) 
					{
						echo "<option value='".$row["distict"]."'".($row["distict"]==$_REQUEST["distict"] ? " selected" : "").">".$row["distict"]."</option>";
					}
			?>
				 </select>
			</div>
		</div>  
           					
            <div class=" container row">
                <div class="col-sm-4"></div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <input name="submit" type="submit" class="btn btn-block btn-primary" value="Search"> </div>
                </div>
                <div class="col-sm-4"></div>
            </div>			
        </div>	
	</form>		
	
</div>	
	
<?php
	
	if ($_REQUEST["distict"]<>'') 
    {
        $search_title = " AND distict='".$_REQUEST["distict"]."'";	
    }					
	
    if ( $_REQUEST["title"]<>'') 
    {
       $sql = "SELECT employes.employes_id, job.user_id, employes.company, employes.distict, employes.indtype,  
	 job.desig, job.exp, job.pay,job.ddate, job.ugcourse, job.postdate, job.skill, job.vacno FROM employes INNER JOIN job ON 
	employes.employes_id=job.user_id where Status='Confirm' and job.ugcourse or job.skill or exp or distict like  '%".$_REQUEST["title"]."%'".$search_title;
    } 
  
    else 
    {
		 $sql = "SELECT employes.employes_id, employes.company, employes.distict, employes.indtype, employes.url,job.id, 
		employes.name, job.desig, job.exp, job.pay, job.pgcourse, job.postdate, job.skill, job.vacno from employes, 
		job where employes.employes_id=job.user_id and Status='Confirm' >0".$search_title;
    }
	

    $sql_result = mysqli_query ($conn, $sql ) or die ('request "Could not execute SQL query" '.$sql);
    if (mysqli_num_rows($sql_result)>0) 
    {
        while ($row = mysqli_fetch_array($sql_result)) 
        {

      echo "<div class='container'>
                <div class='row'>
                    <div class='col-sm-6'>
                        <img class='img-responsive' width='240' height='320'    src='user_fallback.png' title='$row[company]' >
                    </div>

                    <div class='col-sm-6'>
                        <div class='product '>								

                            <div class='pa'>
								<h3><b>Company Name :</b> $row[company]  <br></h3>  
								<h4><b>Company Type  :</b> $row[indtype] <br><h4>
								<h4><b>Distric :</b> $row[distict]  <br></h4> 
                                <h4><b>Skill :</b> $row[skill]  <br></h4> 
                                <h4><b>Url :</b><a href='$row[url]'> $row[url] </a><br></h4>  								
                                <b>Experience :</b> $row[exp] <br>
                                <b>Deadline :</b> $row[ddate] <br>
                                
                                						  
                            </div>
							
							<br>
							
                            <div class='p_title'>	
							
						
							
                        <a  href='companyprofile?j_id=".$row['id']."&c_id=".$row['employes_id']."  ' class='btn btn-default '>Details</a>
							
				
                            </div><br>

                        </div><hr>

                    </div>
                </div>
            </div>";
			?>
			<?php

        }
    } 
    
	
		/*  <a  href='user?p_id=".md5($row['user_id'])."  ' class='btn btn-default '>Details</a>  */
	
	
	else 
		{
			?>
			<div class='alert alert-danger alert-dismissible' role='alert'>
				<button type='button' class='close'  data-dismiss='alert' aria-label='Close'>
					<span aria-hidden='true'>&times;</span>
				</button>
			   <p style='font-size: 20px'><strong>Oops!</strong> No Result Found</p>
			</div>       
			<?php	
		}
	
	
	
 ?>

	
<?php require_once('Footer.php'); ?>		