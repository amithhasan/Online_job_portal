<?php require_once("../session.php"); ?>
<?php require_once("../functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header("Location: ../login.php");
	
	
	}	
?>

<?php
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "e-job"; 


	$conn = mysqli_connect($servername, $username, $password, $dbname);

	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$ssc    	=    $_POST['ssc'];
	$sscb    	=    $_POST['sscb'];
	$sscinst    =    $_POST['sscinst'];
	$sgroup    	=    $_POST['sgroup'];
	$sscgpa    	=    $_POST['sscgpa'];
	$sscpy    	=    $_POST['sscpy'];
	
	$hsc    	=    $_POST['hsc'];
	$hscb    	=    $_POST['hscb'];
	$hscinst    =    $_POST['hscinst'];
	$hgroup    	=    $_POST['hgroup'];
	$hscgpa    	=    $_POST['hscgpa'];
	$hscpy    	=    $_POST['hscpy'];
	
	$honors    	=    $_POST['honors'];
	$honorsb    =    $_POST['honorsb'];
	$honinst    =    $_POST['honinst'];
	$honsub    	=    $_POST['honsub'];
	$honcgpa    =    $_POST['honcgpa'];
	$honpy    	=    $_POST['honpy'];
	
	$mastars    =    $_POST['mastars'];
	$mastarsb   =    $_POST['mastarsb'];
	$mastinst   =    $_POST['mastinst'];
	$mastsub    =    $_POST['mastsub'];
	$mastcgpa   =    $_POST['mastcgpa'];
	$mastpy    	=    $_POST['mastpy'];
	
	$tname    	=    $_POST['tname'];
	$tdur    	=    $_POST['tdur'];
	$tinst    	=    $_POST['tinst'];
	$tinstcont  =    $_POST['tinstcont'];
	$tinstadd   =    $_POST['tinstadd'];
	
	$tname2    	=    $_POST['tname2'];
	$tdur2    	=    $_POST['tdur2'];
	$tinst2    	=    $_POST['tinst2'];
	$tinstcont2 =    $_POST['tinstcont2'];
	$tinstadd2  =    $_POST['tinstadd2'];
	
	
	
	$sql= "INSERT INTO `education`(
	`esl`, `euid`, `ssc`, `sscb`, `sscinst`, `sgroup`, `sscgpa`, `sscpy`, `hsc`, `hscb`, `hscinst`, 
	`hgroup`, `hscgpa`, `hscpy`, `honors`, `honorsb`, `honinst`, `honsub`, `honcgpa`, `honpy`, 
	`mastars`,`mastarsb`, `mastinst`, `mastsub`, `mastcgpa`, `mastpy`,`tname`, `tdur`, `tinst`, 
	`tinstcont`, `tinstadd`, `tname2`, `tdur2`, `tinst2`, `tinstcont2`, `tinstadd2`) 
	VALUES('',	'$pid',		'$ssc',		'$sscb',	'$sscinst',		'$sgroup',		'$sscgpa',		'$sscpy',	
	'$hsc',		'$hscb',	'$hscinst',	'$hgroup',	'$hscgpa',		'$hscpy',		'$honors',		'$honorsb',
	'$honinst',	'$honsub',	'$honcgpa',	'$honpy',	'$mastars',		'$mastarsb',	'$mastinst',	'$mastsub',	
	'$mastcgpa','$mastpy',	'$tname',	'$tdur',	'$tinst',		'$tinstcont',	'$tinstadd',	'$tname2',	
	'$tdur2',	'$tinst2',	'$tinstcont2',	'$tinstadd2')";
	
	
	
	
	if (mysqli_query($conn, $sql)) 
	{
		echo "<script>alert('Successfully Added!'); window.location='profile'</script>";
	} 
	else 
	{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?> 