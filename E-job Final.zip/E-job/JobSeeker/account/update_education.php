<?php require_once("../session.php"); ?>
<?php require_once("../functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header("Location: ../../Login");
	
	
	}	
?>

<?php
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "e-job"; 


	$conn = mysqli_connect($servername, $username, $password, $dbname);

	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	

	$honcgpa    =    $_POST['honcgpa'];
	$honpy    	=    $_POST['honpy'];
	
	$mastars    =    $_POST['mastars'];
	$mastarsb   =    $_POST['mastarsb'];
	$mastinst   =    $_POST['mastinst'];
	$mastsub    =    $_POST['mastsub'];
	$mastcgpa   =    $_POST['mastcgpa'];
	$mastpy    	=    $_POST['mastpy'];
	
	$tname    	=    $_POST['tname'];
	$tdur    	=    $_POST['tdur'];
	$tinst    	=    $_POST['tinst'];
	$tinstcont  =    $_POST['tinstcont'];
	$tinstadd   =    $_POST['tinstadd'];
	
	$tname2    	=    $_POST['tname2'];
	$tdur2    	=    $_POST['tdur2'];
	$tinst2    	=    $_POST['tinst2'];
	$tinstcont2 =    $_POST['tinstcont2'];
	$tinstadd2  =    $_POST['tinstadd2'];
	
	
	
	$sql= "UPDATE `education` SET
	
	`honcgpa` ='$honcgpa', 	`honpy`='$honpy', 		`mastars`='$mastars', 	`mastarsb`='$mastarsb',
	`mastinst`='$mastinst',	`mastsub`='$mastsub',	`mastcgpa`='$mastcgpa', `mastpy`='$mastpy',
	`tname`   ='$tname',		`tdur`='$tdur',			`tinst`='$tinst',		`tinstcont`='$tinstcont',
	`tinstadd`='$tinstadd', `tname2`='$tname2',		`tdur2`='$tdur2',		`tinst2`='$tinst2',
	`tinstcont2`='$tinstcont2',		`tinstadd2`='$tinstadd2' WHERE  euid='".$_SESSION['user_id']."'";
	
	
	
	if (mysqli_query($conn, $sql)) 
	{
		echo "<script>alert('Successfully Updated!'); window.location='profile'</script>";
	} 
	else 
	{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?> 