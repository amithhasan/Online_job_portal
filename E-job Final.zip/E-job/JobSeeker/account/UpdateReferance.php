<?php require_once("../session.php"); ?>
<?php require_once("../functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header("Location: ../../Login");
	
	
	}	
?>

<?php
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "e-job"; 


	$conn = mysqli_connect($servername, $username, $password, $dbname);

	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$name    	=    $_POST['name'];
	$designetion=    $_POST['designetion'];
	$address    =    $_POST['address'];
	$mobile    	=    $_POST['mobile'];
	$relation   =    $_POST['relation'];
	
	$name1    	   =    $_POST['name1'];
	$designetion1  =    $_POST['designetion1'];
	$address1      =    $_POST['address1'];
	$mobile1       =    $_POST['mobile1'];
	$relation1     =    $_POST['relation1'];
	
	

	$sql="UPDATE `refarence` SET
	`name`  ='$name',  `designetion` ='$designetion',  `address` ='$address',  `mobile` ='$mobile', `relation`='$relation', 
	`name1` ='$name1', `designetion1`='$designetion1', `address1`='$address1', `mobile1`='$mobile1',`relation`='$relation'
	WHERE  ruid='".$_SESSION['user_id']."'";
	
	
	
	if (mysqli_query($conn, $sql)) 
	{
		echo "<script>alert('Successfully Added!'); window.location='profile'</script>";
	} 
	else 
	{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?> 

