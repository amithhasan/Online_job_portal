function FillBilling(f) 
{
  if(f.billingtoo.checked == true) {
    f.pvill.value = f.vill.value;
    f.ppo.value = f.po.value;
	f.pthana.value= f.thana.value;
    f.pdist.value =  f.dist.value;
  }
}