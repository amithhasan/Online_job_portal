<?php require_once("../session.php"); ?>
<?php require_once("../functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header("Location: ../../Login");
	
	
	}	
?>

<?php
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "e-job"; 


	$conn = mysqli_connect($servername, $username, $password, $dbname);

	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$name    	=    $_POST['name'];	
	$foccup  	= 	 $_POST['foccup'];	
	$moccup  	= 	 $_POST['moccup'];
	
	
	$mobile  	=    $_POST['mobile'];	
	$hmobile    =    $_POST['hmobile'];			
	
	$nid  		=    $_POST['nid'];	
	$nino  		=    $_POST['nino'];	
	$mstatus  	=    $_POST['mstatus'];	
	$spouse  	=    $_POST['spouse'];	
	$height  	=    $_POST['height'];	
	$weight  	=    $_POST['weight'];
	
		
	$pvill  	=    $_POST['pvill'];	
	$ppo  		=    $_POST['ppo'];	
	$pthana  	=    $_POST['pthana'];	
	$pdist  	=    $_POST['pdist'];	
		
	
	$sql= "UPDATE `basic_info` SET 
	`name`   ='$name',	  `foccup`='$foccup',	`moccup`='$moccup',   `mobile` ='$mobile',
	`hmobile`='$hmobile', `nid`	  ='$nid',   	`nino`  ='$nino',	  `mstatus`='$mstatus', 
	`spouse` ='$spouse',  `height`='$height',	`weight`='$weight',	  `pvill`  ='$pvill', 
	`ppo`    ='$ppo',	  `pthana`='$pthana',	`pdist` ='$pdist'  
	 WHERE  uid='".$_SESSION['user_id']."'";
	

	if (mysqli_query($conn, $sql)) {
		echo "<script>alert('Successfully Updated!'); window.location='index.php'</script>";
	} 
	else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?> 

