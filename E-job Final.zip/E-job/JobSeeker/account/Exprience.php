<?php require_once("../session.php"); ?>
<?php require_once("../functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header("Location: ../login");
	
	
	}	
?>

<?php
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "e-job"; 


	$conn = mysqli_connect($servername, $username, $password, $dbname);

	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$skill			= $_POST['skill'];
	
	$company		= $_POST['company'];
	$designetion	= $_POST['designetion'];
	$address		= $_POST['address'];
	$duration		= $_POST['duration'];
	$mobile			= $_POST['mobile'];
	
	$company1		= $_POST['company1'];
	$designetion1	= $_POST['designetion1'];
	$address1		= $_POST['address1'];
	$duration1		= $_POST['duration1'];
	$mobile1		= $_POST['mobile1'];
	
	$company2		= $_POST['company2'];
	$designetion2	= $_POST['designetion2'];
	$address2		= $_POST['address2'];
	$duration2		= $_POST['duration2'];
	$mobile2		= $_POST['mobile2'];
	
	
	
	
	$sql= "INSERT INTO `experience`(`exsl`, `exuid`,  `skill`,  `company`,  `designetion`,  `address`,   `duration`,   `mobile`,  `company1`,   `designetion1`,   `address1`,   `duration1`,   `mobile1`,  `company2`,   `designetion2`,   `address2`,   `duration2`,   `mobile2`) VALUES
								   ('',    '$pid',   '$skill', '$company', '$designetion', '$address',  '$duration',  '$mobile', '$company1',  '$designetion1',  '$address1',  '$duration1',  '$mobile1', '$company2',   '$designetion2',  '$address2',  '$duration2',  '$mobile2')";
	
	
	if (mysqli_query($conn, $sql)) 
	{
		echo "<script>alert('Successfully Added!'); window.location='profile'</script>";
	} 
	else 
	{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?> 

