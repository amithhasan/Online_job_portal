<?php require_once("config.php"); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];

    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('location:../index');
	
	}	
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css" >
    <link rel="stylesheet" href="../css/style.css" >
	
    <script type="text/javascript" src="../js/jquery.pwdMeter.js"></script>	
    <script src="dist/js/jquery.min.js"></script>
    <script src="dist/js/bootstrap.min.js"></script>

	<style>
	  .count{
	   background:red;
	   position:relative;
	   top: -20px;
	   left: -35px;
	}
	</style>
	<style>

.dropbtn {
    background-color: #F8F8F8;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
}

.drop {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.drop:hover .dropdown-content {
    display: block;
}

.drop:hover .dropbtn {
    background-color: #337AB7;
}
</style>
	
</head>

<body>
<div class="container">
        <br><br><br>
	    <div class="row">
            <div class="col-sm-12">
                <img class="img-responsive"  src="../images/01.jpg" alt="">
            </div>
        </div>
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand">E-Job </a>
                </div>
				
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a style="font-size:18px" href='index'>&nbsp;Home</a></li>
                        <li><a style="font-size:18px" href='profile'>&nbsp;Profile</a></li>
                        <li><a style="font-size:18px" href="interview"> Interview</a></li>
                        <li><a style="font-size:18px"href="Contact"> Contact</a></li>
						<li class="dropdown">
						   <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
						   <span class="glyphicon glyphicon-globe" style="font-size:20px;"></span>
						   <span class="label label-pill label-danger count" ></span></a>
						   <ul class="dropdown-menu"></ul>
						</li>
                    </ul>

                    <ul class="nav navbar-nav left">
						<div class="drop">	
						
		
						 <button class="dropbtn"><i class="fa fa-user"></i>&nbsp;<?php  echo $Name; ?> &nbsp; <span class='caret'></span></button>
						 <div class="dropdown-content">         
							<a href='account/index'></i>&nbsp; Account</a>
							<a href='update_password'></i>&nbsp; Change Password </a>
							<a href='logout'></i>&nbsp; Log Out</a>                   
						  </div>
						</div>
                    </ul>
                </div>           
            </div>       
	   </nav>    
</div>
 </body>
</html>
<script>
$(document).ready(function(){
 
 function load_unseen_notification(view = '')
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{view:view},
   dataType:"json",
   success:function(data)
   {
    $('.dropdown-menu').html(data.notification);
    if(data.unseen_notification > 0)
    {
     $('.count').html(data.unseen_notification);
    }
   }
  });
 }
 
 load_unseen_notification();
 
 $('#comment_form').on('submit', function(event){
  event.preventDefault();
  if($('#subject').val() != '' && $('#comment').val() != '')
  {
   var form_data = $(this).serialize();
   $.ajax({
    url:"../Employers/postjob.php",
    method:"POST",
    data:form_data,
    success:function(data)
    {
     $('#comment_form')[0].reset();
     load_unseen_notification();
    }
   });
  }
  else
  {
   alert("Both Fields are Required");
  }
 });
 
 $(document).on('click', '.dropdown-toggle', function(){
  $('.count').html('');
  load_unseen_notification('yes');
 });
 
 setInterval(function(){ 
  load_unseen_notification();; 
 }, 5000);
 
});
</script>
