<?php require_once('config.php'); ?>
<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php require_once('header.php'); ?>
<?php 
    if(logged_in())
    {
	$Name=$_SESSION['name'];
	$user=$_SESSION['username'];   //_SESSION is a PHP keyword
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else{
	$user=NULL;
	$pass=NULL;
	header('Location: ../Login');
		
	}	
?>
<?php
if(isset($_POST['Submit']))
{
	$sql=mysqli_query($conn, "SELECT password FROM users where password ='".hash('sha256', $_POST['oldpass'])."'");
	$num=mysqli_fetch_array($sql);
	if($num>0)
	{
	 $con=mysqli_query($conn, "update users set password ='".hash('sha256', $_POST['newpass'])."' where user_id='".$_SESSION['user_id']."'");
	 echo"<script>alert('Password Changed Successfully'); window.location='index'</script> ";
	}
	else
	{
		$_SESSION['msg']="Old Password not match !!";
	}
}
?>
<script language="javascript" type="text/javascript">
function valid()
{
	if(document.form1.oldpass.value=="")
	{
		alert(" Old Password Field Empty !!");
		document.form1.oldpass.focus();
		return false;
	}
	else if(document.form1.newpass.value=="")
	{
		alert(" New Password Field Empty !!");
		document.form1.newpass.focus();
		return false;
	}
	else if(document.form1.confirmpassword.value=="")
	{
		alert(" Confirm Password Field Empty !!");
		document.form1.confirmpassword.focus();
		return false;
	}
	else if(document.form1.newpass.value.length<6)
	{
		alert("New Password Field length must be atleast of 6 characters !!");
		document.form1.newpass.focus();
		return false;
	}
	else if(document.form1.confirmpassword.value.length<6)
	{
		alert(" Confirm Password Field less than 6 characters !!");
		document.form1.confirmpassword.focus();
		return false;
	}
	else if(document.form1.newpass.value!= document.form1.confirmpassword.value)
	{
		alert("New Password and Confirm Password Field not match  !!");
		document.form1.newpass.focus();
		return false;
	}
	return true;
}
</script>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Admin | Change Password</title>
    <link href="css/bootstrap.css" rel="stylesheet">   
  </head>

  <body>

	<div class="container row">
	
        <div class="col-md-12">
            <div class="content-panel">
                <form class="form-horizontal style-form" name="form1" method="post" action="" onSubmit="return valid();">
                           
                          
						<div class="alert alert-danger alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> 
							<?php echo $_SESSION['msg'];?> <?php echo $_SESSION['msg']="";?>
						 </div>

						  
						  <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Old Password</label>
                              <div class="col-sm-10">
                                  <input type="password" class="form-control" name="oldpass" value="" >
                              </div>
                          </div>
                          
                              <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">New Password</label>
                              <div class="col-sm-10">
                                  <input type="password" class="form-control" name="newpass" value="" >
                              </div>
                          </div>
                          
                              <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Confirm Password</label>
                              <div class="col-sm-10">
                                  <input type="password" class="form-control" name="confirmpassword" value="" >
                              </div>
                          </div>
                          <div style="margin-left:100px;">
                          <input type="submit" name="Submit" value="Change" class="btn btn-theme"></div>
                </form>
            </div>
        </div>
    </div>
  </body>
</html>
