-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2018 at 04:55 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `e-job`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `apply`
--

CREATE TABLE IF NOT EXISTS `apply` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `job_id` int(10) NOT NULL,
  `u_id` int(10) NOT NULL,
  `c_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `apply`
--

INSERT INTO `apply` (`id`, `job_id`, `u_id`, `c_id`) VALUES
(19, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `basic_info`
--

CREATE TABLE IF NOT EXISTS `basic_info` (
  `sl` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `foccup` varchar(100) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `moccup` varchar(100) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `hmobile` varchar(20) NOT NULL,
  `bdate` varchar(20) NOT NULL,
  `blood` varchar(10) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `nid` varchar(20) NOT NULL,
  `nino` bigint(20) DEFAULT NULL,
  `mstatus` varchar(20) NOT NULL,
  `spouse` varchar(50) NOT NULL,
  `height` varchar(5) NOT NULL,
  `weight` varchar(10) NOT NULL,
  `vill` varchar(50) NOT NULL,
  `po` varchar(50) NOT NULL,
  `thana` varchar(50) NOT NULL,
  `dist` varchar(50) NOT NULL,
  `pvill` varchar(50) NOT NULL,
  `ppo` varchar(50) NOT NULL,
  `pthana` varchar(50) NOT NULL,
  `pdist` varchar(50) NOT NULL,
  PRIMARY KEY (`sl`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `basic_info`
--

INSERT INTO `basic_info` (`sl`, `uid`, `name`, `fname`, `foccup`, `mname`, `moccup`, `gender`, `email`, `mobile`, `hmobile`, `bdate`, `blood`, `religion`, `nationality`, `nid`, `nino`, `mstatus`, `spouse`, `height`, `weight`, `vill`, `po`, `thana`, `dist`, `pvill`, `ppo`, `pthana`, `pdist`) VALUES
(1, 4, 'Md. Amith Hasan', 'Md. Zillur Rahman', 'Farmer', 'Mrs. Hasniyera Begum', 'Housewife', 'Male', 'amithasan856@gmail.com', '01755455511', '01883060511', '05/08/1994', 'B+', 'Islam', 'Bangladeshi', 'Yes', 19948118227000555, 'Single', '', '5.8', '58kg', 'Dhadash(3)', 'Banesware(6260)', 'Puthia', 'Rajshahi', 'Dhadash(3)', 'Banesware(6260)', 'Puthia', 'Dhaka'),
(7, 2, 'Md Mridul ', 'ABC', 'Job', 'AAAAAA', 'Housewife', 'male', 'aaa@gmail.com', '0123456789', '01755455511', '09/26/2017', 'AB+', 'Islam', 'bang', 'Yes', 12345678912345678, 'Single', '', '5.8"', '60kg', 'sdf', 'ert', 'ert', 'Dhaka', 'Nator', '5552', 'Nator', 'Rajshahi'),
(8, 6, 'Mridul', 'AAAAA', 'Job', 'Mrs', 'House wife', 'Male', 'mridul@gmail.com', '01755455511', '721 1321', '12/27/1998', 'A+', 'Islam', 'Bangladeshi', 'Yes', 12345612345612345, 'Single', '', '5.10', '70', 'Nator', 'Tebaria', 'Nator', 'Rajshahi', 'Nator', 'Tebaria', 'Nator', 'Rajshahi'),
(9, 7, 'Alamin', 'Father', 'Teacher', 'Mother', 'Home Maker', 'Male', 'alamin@gmail.com', '1234545612345', '123456', '04/03/1992', 'AB+', 'Islam', 'Bangladeshi', 'Yes', 12345612345612345, 'Single', '', '5.6', '60', 'Nator', 'Natore', 'Singra', 'Rajshahi', 'Nator', 'Natore', 'Singra', 'Rajshahi'),
(10, 3, 'Amit Hasan', 'Zillur Rahman', 'Farmar', 'Hasniyera Begum', 'Home maker', 'Male', 'amithasan856@gmail.com', '01755455511', '123456', '08/05/1994', 'B+', 'Islam', 'Bangladeshi', 'Yes', 19948118227000111, 'Single', '', '5.7''', '60', 'Dhadash', 'Baneswar', 'Puthia', 'Rajshahi', 'Dhadash', 'Baneswar', 'Puthia', 'Rajshahi'),
(11, 1, 'Aminul', 'Md', 'Teacher', 'Mrs', 'Hm', 'Female', 'aminul@gmail.com', '01711223344', '12345612312', '12/01/1994', 'A+', 'Islam', 'Bangladeshi', 'Yes', 19948118227000555, 'Single', '', '5.6', '70', 'Gretar Road', '1234', 'Boalia', 'Rajshahi', 'Gretar Road', '1234', 'Boalia', 'Rajshahi');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` int(11) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `comment` varchar(5000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `mobile`, `subject`, `comment`) VALUES
(1, 'Amit', 'amit@yahoo.com', 1223457698, 'CSE', 'ewweewe'),
(2, 'cse', 'cse@gmail.com', 1755455511, 'cse', ' aaaaaaaaaaaaaaaaaaaaaa');

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE IF NOT EXISTS `education` (
  `esl` int(10) NOT NULL AUTO_INCREMENT,
  `euid` int(10) NOT NULL,
  `ssc` varchar(50) NOT NULL,
  `sscb` varchar(50) NOT NULL,
  `sscinst` varchar(100) NOT NULL,
  `sgroup` varchar(50) NOT NULL,
  `sscgpa` float NOT NULL,
  `sscpy` int(4) NOT NULL,
  `hsc` varchar(50) NOT NULL,
  `hscb` varchar(50) NOT NULL,
  `hscinst` varchar(100) NOT NULL,
  `hgroup` varchar(50) NOT NULL,
  `hscgpa` float NOT NULL,
  `hscpy` int(4) NOT NULL,
  `honors` varchar(50) NOT NULL,
  `honorsb` varchar(100) NOT NULL,
  `honinst` varchar(100) NOT NULL,
  `honsub` varchar(100) NOT NULL,
  `honcgpa` float NOT NULL,
  `honpy` int(6) NOT NULL,
  `mastars` varchar(50) NOT NULL,
  `mastarsb` varchar(100) NOT NULL,
  `mastinst` varchar(100) NOT NULL,
  `mastsub` varchar(100) NOT NULL,
  `mastcgpa` varchar(6) NOT NULL,
  `mastpy` varchar(6) NOT NULL,
  `tname` varchar(100) NOT NULL,
  `tdur` varchar(50) NOT NULL,
  `tinst` varchar(100) NOT NULL,
  `tinstcont` varchar(20) NOT NULL,
  `tinstadd` varchar(200) NOT NULL,
  `tname2` varchar(100) NOT NULL,
  `tdur2` varchar(50) NOT NULL,
  `tinst2` varchar(200) NOT NULL,
  `tinstcont2` varchar(20) NOT NULL,
  `tinstadd2` varchar(200) NOT NULL,
  PRIMARY KEY (`esl`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`esl`, `euid`, `ssc`, `sscb`, `sscinst`, `sgroup`, `sscgpa`, `sscpy`, `hsc`, `hscb`, `hscinst`, `hgroup`, `hscgpa`, `hscpy`, `honors`, `honorsb`, `honinst`, `honsub`, `honcgpa`, `honpy`, `mastars`, `mastarsb`, `mastinst`, `mastsub`, `mastcgpa`, `mastpy`, `tname`, `tdur`, `tinst`, `tinstcont`, `tinstadd`, `tname2`, `tdur2`, `tinst2`, `tinstcont2`, `tinstadd2`) VALUES
(1, 4, 'SSC', 'Rajshahi', 'Dhadash High School', 'Science', 4.94, 2010, 'HSC', 'Rajshahi', 'Agrani School & College', 'HSC', 3.8, 2012, 'B.sc Honors', 'Varendra University', 'Varendra University', 'CSE', 3.62, 2018, '', '', '', '', '', '', 'Web Design & Development.', 'Six Month.', 'Base IT.', '01717111111', 'Rajshahi New Market.', '', '', '', '', ''),
(2, 8, 'SSC', 'Dhaka', 'Dhaka city collage', 'Science', 5, 2010, 'HSC', 'Dhaka', 'Dhaka city collage', 'HSC', 5, 2012, 'Honurs', 'Dhaka University', 'Dhaka University', 'CSE', 3.5, 2016, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, 3, 'SSC', 'Rajshahi', 'Dhadash High School', 'Science', 4.94, 2010, 'Equivalent', 'Rajshahi', 'Agrani Collage', 'HSC', 4, 2012, 'Honurs', 'Varendra University', 'Varendra University', 'CSE', 3.5, 2018, '', '', '', '', '', '', 'Web Development', '4 Month', 'Base IT', '123456', 'Rajshahi', '', '', '', '', ''),
(4, 2, 'SSC', 'Rajshahi', 'Agrani Collage', 'Science', 5, 2010, 'HSC', 'Rajshahi', 'Agrani Collage', 'Science', 4, 2012, 'B.sc', 'Rajshahi University', 'Rajshahi University', 'CSE', 3.5, 2016, 'M.sc', 'Rajshahi University', 'Rajshahi University', 'CSE', '3.40', '2018', '', '', '', '', '', '', '', '', '', ''),
(5, 1, 'SSC', 'Rajshahi', 'Agrani Collage', 'Science', 5, 2010, 'Equivalent', 'Rajshahi', 'City Collage', 'Science', 5, 2012, 'B.sc', 'RUET', 'RUET', 'CSE', 3.9, 2016, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(6, 6, 'SSC', 'Rajshahi', 'NS College', 'Science', 4.5, 2010, 'Equivalent', 'Rajshahi', 'City Collage', 'Science', 4, 2012, 'B.sc', 'Varendra Uviversity', 'Varendra Uviversity', 'Civil', 3.3, 2016, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(7, 7, 'SSC', 'Dhaka', 'Agrani Collage', 'Science', 5, 2009, 'HSC', 'Dhaka', 'City Collage', 'Science', 4, 2012, 'B.sc', 'Varendra Uviversity', 'Varendra Uviversity', 'ICE', 3.9, 2016, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `employes`
--

CREATE TABLE IF NOT EXISTS `employes` (
  `employes_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `company` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `indtype` varchar(500) NOT NULL,
  `distict` varchar(20) NOT NULL,
  `details` varchar(1000) NOT NULL,
  `url` varchar(50) NOT NULL,
  PRIMARY KEY (`employes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `employes`
--

INSERT INTO `employes` (`employes_id`, `name`, `username`, `company`, `email`, `password`, `mobile`, `indtype`, `distict`, `details`, `url`) VALUES
(1, 'Stive Job', 'intel', 'Microsoft', 'intel@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', '01755455511', 'Education/Training/Teaching', 'Dhaka', 'Our company is biggest in the world.', 'www.intel.com'),
(2, 'Ahsan', 'vu', 'Varendra', 'vu@edu.bd', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', '01712345678', 'Education/Training/Teaching', 'Rajshahi', 'It is beautiful company.', 'www.vu.edu.bd'),
(3, 'Mahbub', 'raj-it', 'Raj-IT', 'raj-it@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', '01711111111', 'Software Services', 'Rajshahi', 'It it sector work.', 'www.raj-it.com');

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE IF NOT EXISTS `experience` (
  `exsl` int(10) NOT NULL AUTO_INCREMENT,
  `exuid` int(10) NOT NULL,
  `skill` varchar(500) NOT NULL,
  `company` varchar(100) NOT NULL,
  `designetion` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `company1` varchar(100) NOT NULL,
  `designetion1` varchar(100) NOT NULL,
  `address1` varchar(200) NOT NULL,
  `duration1` varchar(50) NOT NULL,
  `mobile1` varchar(12) NOT NULL,
  `company2` varchar(100) NOT NULL,
  `designetion2` varchar(100) NOT NULL,
  `address2` varchar(200) NOT NULL,
  `duration2` varchar(50) NOT NULL,
  `mobile2` varchar(12) NOT NULL,
  PRIMARY KEY (`exsl`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `experience`
--

INSERT INTO `experience` (`exsl`, `exuid`, `skill`, `company`, `designetion`, `address`, `duration`, `mobile`, `company1`, `designetion1`, `address1`, `duration1`, `mobile1`, `company2`, `designetion2`, `address2`, `duration2`, `mobile2`) VALUES
(1, 4, 'C, C++, Java, Php', 'Varendra University', 'Student', 'Rajshahi Bangladesh', '5 Years', '1234561234', '', '', '', '', '', '', '', '', '', ''),
(2, 3, 'C, C++, Java, Php', 'Vu', 'Student', 'Rajshahi', '4 Years', '01755455511', '', '', '', '', '', '', '', '', '', ''),
(3, 2, 'Java, html, css, bootstrap, php, mysql', 'BTCL', 'Maneger', 'Rajshahi', '2', '01711223344', '', '', '', '', '', '', '', '', '', ''),
(4, 1, 'C, C++, Java, html, css, bootstrap, php, mysql, Oracol', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(5, 6, 'Java, html, css, bootstrap, php, mysql', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(6, 7, 'C, C++, Java, html, css, bootstrap, php, mysql, Oracol, micocontroler, assembly, prolog', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `imsl` int(10) NOT NULL AUTO_INCREMENT,
  `imuid` int(10) NOT NULL,
  `userPic` varchar(200) NOT NULL,
  `ip_address` varchar(100) NOT NULL,
  PRIMARY KEY (`imsl`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`imsl`, `imuid`, `userPic`, `ip_address`) VALUES
(1, 8, '573791.jpg', '::1'),
(2, 1, '945246.jpg', '::1'),
(3, 4, '811133.jpg', '::1'),
(4, 2, '637479.jpg', '::1'),
(5, 3, '750830.jpg', '::1'),
(6, 5, '168496.jpg', '127.0.0.1'),
(7, 7, '898905.jpg', '127.0.0.1'),
(8, 6, '749397.jpg', '127.0.0.1'),
(9, 9, '610955.jpg', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE IF NOT EXISTS `job` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `desig` varchar(100) NOT NULL,
  `vacno` int(5) NOT NULL,
  `jobdesc` varchar(2000) NOT NULL,
  `exp` varchar(20) NOT NULL,
  `pay` varchar(10) NOT NULL,
  `skill` varchar(200) NOT NULL,
  `ugcourse` varchar(100) NOT NULL,
  `pgcourse` varchar(100) NOT NULL,
  `profile` varchar(2000) NOT NULL,
  `status` varchar(10) NOT NULL,
  `postdate` varchar(20) NOT NULL,
  `comment_status` int(1) NOT NULL,
  `ddate` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`id`, `user_id`, `desig`, `vacno`, `jobdesc`, `exp`, `pay`, `skill`, `ugcourse`, `pgcourse`, `profile`, `status`, `postdate`, `comment_status`, `ddate`) VALUES
(1, 1, 'IT Officer', 2, 'All IT sector work can maintenance.', 'Freshers', '12500', 'C, C++, Java, Php, Mysql', 'B.Sc', '', 'Open minded', 'Confirm', '12-02-18', 1, '06/01/2018'),
(2, 2, 'Assistent Lecturer', 1, 'All things', '1', '20000', 'C, C++, Java, Php, Mysql', 'B.Sc', 'Not Pursuing Post Graduation', 'good', 'Confirm', '01-02-18', 1, '07/07/2018'),
(7, 3, 'Web Designer', 2, 'Experience in web development.', '1', '25000', 'Java, html, css, bootstrap, php, mysql', 'B.Sc', 'Not Pursuing Post Graduation', 'Open minded.', 'Confirm', '16-02-18', 1, '07/01/2018'),
(9, 3, 'Web Designer', 1, 'Desired Candidate Profile:', '3', '25000', 'Java, html, css, bootstrap, php, mysql', 'B.Sc', 'M.Sc', 'Desired Candidate Profile:', 'Confirm', '17-02-18', 1, '06/05/2018'),
(10, 1, 'HR Manager', 1, 'Welcome\r\n\r\nTCS Private Limited', '5', '40000', 'Java, html, css, bootstrap, php, mysql', 'B.Sc', 'M.Sc', 'Welcome\r\n\r\nTCS Private Limited\r\n', 'Pending', '17-02-18', 1, '06/06/2018'),
(11, 1, 'Php Developer', 2, 'Php at least 5 years experience', '5', '40000', 'php,mysql', 'CSE', 'M.Sc', 'Open minded', 'Confirm', '16-05-18', 1, '06/01/2018');

-- --------------------------------------------------------

--
-- Table structure for table `jobinvite`
--

CREATE TABLE IF NOT EXISTS `jobinvite` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `usr_id` int(10) NOT NULL,
  `c_id` int(10) NOT NULL,
  `time` varchar(10) NOT NULL,
  `date` varchar(20) NOT NULL,
  `attach` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `jobinvite`
--

INSERT INTO `jobinvite` (`id`, `usr_id`, `c_id`, `time`, `date`, `attach`) VALUES
(1, 1, 2, '12.00pm', '05/28/2018', 'asdad');

-- --------------------------------------------------------

--
-- Table structure for table `refarence`
--

CREATE TABLE IF NOT EXISTS `refarence` (
  `rsl` int(10) NOT NULL AUTO_INCREMENT,
  `ruid` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `designetion` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `relation` varchar(50) NOT NULL,
  `name1` varchar(50) NOT NULL,
  `designetion1` varchar(100) NOT NULL,
  `address1` varchar(200) NOT NULL,
  `mobile1` varchar(12) NOT NULL,
  `relation1` varchar(100) NOT NULL,
  PRIMARY KEY (`rsl`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `refarence`
--

INSERT INTO `refarence` (`rsl`, `ruid`, `name`, `designetion`, `address`, `mobile`, `relation`, `name1`, `designetion1`, `address1`, `mobile1`, `relation1`) VALUES
(2, 4, 'Sadiqur Rahman', 'BTCL Maneger', 'Rajshahi', '01755455511', 'Teacher', '', '', '', '', ''),
(3, 6, 'Amit', 'IT-Manager', 'Rajshahi', '01755455511', 'Brother', '', '', '', '', ''),
(4, 8, 'Amit', 'student', 'Rajshahi', '1223123', 'Brother', '', '', '', '', ''),
(5, 3, 'amit', 'Student', 'Rajshahi', '01755455511', 'Brother', '', '', '', '', ''),
(6, 2, 'Amit', 'HR', 'Rajshahi', '01711223344', 'Brother', '', '', '', '', ''),
(7, 1, 'Sadik', 'Maneger', 'Rajshahi', '01711223344', 'Brother', '', '', '', '', ''),
(8, 7, 'Aminul', 'Maneger', 'Rajshahi', '01711223344', 'Brother', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `username`, `gender`, `email`, `password`) VALUES
(1, 'Hasan', 'hasan', 'Male', 'hasan@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
(2, 'aaaa', 'aaaaa', 'Male', 'aaa@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
(3, 'Amit', 'amit', 'Male', 'amithasan856@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
(4, 'Admin', 'admin', 'Male', 'admin@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
(5, 'Amith Hasan', 'amithasan', 'Male', 'amithhasan794@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
(6, 'Mridul', 'mridul', 'Male', 'mridul@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
(7, 'Alamin', 'alamin', 'Male', 'alamin@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
(8, 'Mother Land', 'land', 'Female', 'land@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
(9, 'Mridul', 'mijanur', 'Male', 'mijanur@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
